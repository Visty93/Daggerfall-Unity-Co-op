# Daggerfall Unity Co-op — Multiplayer API v0.5

This is the developer-facing API for mods that add multiplayer behavior to an existing Daggerfall Unity mod. It exposes session identity and parties, messages, retained state, shared world objects and loot, native enemy control, **existing-network-enemy behaviors and combat events**, moving-frame support, and **simple GameObject synchronization**. Mod adapters use the `DaggerfallCoop.API` namespace.

## Getting started

The co-op runtime provides these components:

| Source | Responsibility |
| --- | --- |
| `MultiplayerAPI.cs` | Sessions, players, party queries, messaging, retained state and coordinates |
| `MultiplayerAPIWorld.cs` | Shared world records, motion policies, pickups, loot and native enemies |
| `MultiplayerAPISyncObjects.cs` | Flag-based registration of existing GameObjects, prefab replicas, pickable objects and moving platforms |
| `MultiplayerAPIEnemyBehavior.cs` | Scripted-enemy behavior registration, persistent ownership and companion roots |
| `MultiplayerAPIExistingEnemies.cs` | Existing network-enemy lifecycle, simulation-authority updates and per-mod behavior attachments |
| `MultiplayerAPICombat.cs` | Server-validated combat phases and target-hit requests for existing co-op enemies |
| `MultiplayerAPIMovingFrames.cs` | Independent root following, enemy-on-platform carrying and local-player moving surfaces |
| `NetworkEnemyRootGuard.cs` | Native network-enemy root parenting policy |
| `CompanionSessionCompatibility.cs` | Companion import and local-to-multiplayer session transitions |

All co-op participants (including a dedicated server) should run the **same game build** containing these sources. A mod developer compiles an adapter against that build and packages their own mod as a `.dfmod`; they should **not** bundle these co-op source files in their `.dfmod`. Mod adapters call the public API methods from their own code.

`MultiplayerAPI.ApiVersion` is `5`. Check the API version and the required co-op build when your mod starts. Register handlers, factories and behaviors on the relevant peers before requesting shared objects or enemies.

**Initialize the adapter:**

```csharp
using DaggerfallCoop.API;
ModWorld world = MultiplayerAPI.OpenWorld(ModGuid, CreateOrUpdateReplica);
if (world.Ready)
    world.Claim(encounterKey, OnClaimResult);
```

Use stable mod GUIDs and object keys. Register factories, handlers and enemy behaviors on the server and clients before submitting requests. Keep normal single-player gameplay working when no multiplayer session is active.

## Simple GameObject synchronization

For a mod that creates an ordinary GameObject (a flower, placed prop, cart, moving platform), use `OpenSyncWorld()` instead of implementing message handlers and a world factory. A **kind** identifies the type of object, such as `"rose"`; a **key** identifies the individual object, such as `"rose/0a12..."`. All participants must register the same kinds, with local visual prefabs or a factory that builds them. Do not identify instances by scene object names or nearby positions.

The API synchronizes the object's identity, position, rotation, public state and removal. Each receiving peer creates a visual copy from its installed prefab. **Only the creator runs the original gameplay scripts**. The visual prefab should not independently execute gameplay, grant items, or spawn other objects. If the **same single-player spawn event runs on every client**, first choose one gameplay owner (for example using `Claim()`); otherwise each client can register a separate object, producing duplicates. A flag does not automatically deduplicate unrelated SP events.

```csharp
// Initialize on every peer. Each mod must choose its own stable GUID.
ModSyncWorld sync = MultiplayerAPI.OpenSyncWorld(modGuid);
sync.RegisterPrefab("rose", memorialRosePrefab, OnRoseTaken);

// Mark a NEW object created by the mod. The marker waits until co-op is ready.
existingRose.AddComponent<ModSyncMarker>().Configure(
    sync, "rose/" + Guid.NewGuid().ToString("N"), "rose",
    new ModSyncOptions {
        Motion = ModWorldMotion.Fixed,
        Flags = ModSyncFlags.Pickable | ModSyncFlags.AutoPickupOnClick,
        LifetimeSeconds = 1800f,
    }, "red");

// Only the winner of a server-approved pickup gets this callback.
// OnRoseTaken(ModWorldRecord record) adds YOUR mod's item to local inventory.
```

`ModSyncMarker` is an optional Unity component, not a requirement. You can also add it to an authored GameObject in the Unity Inspector and set `WorldGuid`, `Key`, `Kind`, `Options` and `CustomData` there. Call `OpenSyncWorld()` and `RegisterPrefab()` in your mod startup code; the marker resolves that world by GUID when multiplayer becomes ready. Give each spawned instance a unique key—do not duplicate a prefab with the same fixed key. A mod can call `sync.Register(source, key, kind, options, customData)` directly after `sync.Ready` becomes true. The returned `bool` means the request was submitted, **not** that the server accepted it; provide the completion callback when you need acknowledgement. The marker submits once after readiness and logs a rejected registration. A source GameObject's destruction automatically requests removal of its shared record. Do not publish the same source into multiple world-sync systems; this API rejects objects already bound to a `ModWorld`.

### Registration options

| Option | What it does |
| --- | --- |
| `Motion = Fixed` | Placed objects stay in place. Recommended for flowers, chalk marks and static props. |
| `Motion = Default` | Lower-rate movement updates (about 4/s) with basic presentation smoothing. |
| `Motion = Smooth` | Moving objects update at about 8/s; receiving peers interpolate position and rotation. |
| `Flags = Pickable` | Allow the mod to request a one-winner server-validated pickup using `sync.Take(key)`. |
| `Flags = Pickable | AutoPickupOnClick` | Automatically install a pickup click handler on available colliders. Register an `onPickedUp` callback to grant the inventory item. |
| `Flags = KeepOriginalParent` | Preserve the source's local parent. It does not synchronize the Unity parent relationship. |
| `Flags = CarryLocalPlayer` | On **remote visual replicas**, enable carrying of the local player standing on a marked deck collider. Requires `Motion = Smooth` or `Default`. |
| `LifetimeSeconds` | World record lifetime in seconds; `0` means no time-based expiry. |
| `VisibilityMetres` | Maximum visual range (default 250m, server accepts 1–3000m). It does not extend the 80m initial creation-request range. |

To support `CarryLocalPlayer`, put `ModSyncCarrySurface` on the designated, non-trigger deck collider in your **replica prefab**. A prefab with just one suitable root collider can use that collider without a marker. The source owner's normal mod code continues to carry its own player; the API carries players on remote presentation copies only. Do not use a second carrying implementation on the same surface.

For procedural visuals rather than prefabs, call `sync.RegisterFactory(kind, factory, onPickedUp, applyData)`. The factory receives the record and an existing object (or `null`); when an existing object is supplied, update and return **that same GameObject**. `applyData` receives the mod's custom payload after construction and when it changes. Use `sync.UpdateData(key, json)` to publish new payload data; `ModSyncWorld.GetCustomData(record)` extracts it from a pickup or snapshot record. `sync.TryGetObject()`, `sync.Snapshot`, `sync.Remove()`, and `sync.Claim()` expose common world operations. Call `Dispose()` when the adapter shuts down.

`AutoPickupOnClick` only installs a callback on colliders that do **not** already implement DFU's `IPlayerActivable`. If your mod has its own activation component, keep it and call `sync.Take(key)` from that existing interaction instead. The API never adds inventory items by itself; `onPickedUp` runs only on the player whose server-authorized pickup succeeded. A failed inventory grant is not automatically rolled back. GameObjects have to exist near the registering player and the relevant world area must be loaded. The API does not serialize these mod world objects into saves or automatically synchronize unrelated enemy AI, helms, doors, or private inventories.

See `Examples/MultiplayerAPISimpleSyncExample.cs` for a complete component-based flower and moving-platform example. The advanced `OpenWorld()` API remains available for native enemies, containers and custom synchronization rules.

## Players, parties and authority

`MultiplayerAPI.IsActive`, `IsServer`, `IsClient` and `IsHost` describe the process role; they do not guarantee that the local player has spawned. `LocalPlayerId` is zero when no ready local player is present (including on a dedicated server).

| API | Purpose |
| --- | --- |
| `GetPlayers()` | Snapshot of known players; `MultiplayerPlayer` provides `NetId`, `Name`, `GameObject`, `PartyId`, `PartyLeaderNetId`, and `IsLocal`. |
| `TryGetPlayer(id, out player)` / `IsPlayerConnected(id)` | Resolve a session-local ID or check a known connection. |
| `GetPartyId(id)` / `GetPartyLeaderId(id)` | Query known party and leader identity. Zero means unavailable. |
| `AreInSameParty(a, b)` / `GetPartyMembers(id)` | Query membership and known member IDs. |
| `PlayerJoined`, `PlayerLeft`, `PartyStateChanged`, `SessionEnded` | Session change notifications. Unsubscribe during adapter teardown. |
| `TryGetNetworkId(obj, out id)` / `TryGetNetworkObject(id, out obj)` | Resolve existing Mirror network identities. These do not spawn a prefab. |
| `TryGetEnemyWorldPosition(enemy, out position)` | Read a networked **exterior enemy's** synchronized DF-world X/Z without accessing co-op implementation components. Returns `false` if metadata is unavailable or the enemy is indoors/in a dungeon. |
| `IsAuthoritativeFor(obj)` / `GetOwnerPlayerId(obj)` | Query local simulation authority and observed connection ownership. |

A world record's logical owner (`OwnerPlayerId`) is not necessarily the peer currently simulating its native networked enemy. For movement of a Mirror actor, check `IsAuthoritativeFor()` after any ownership claim. Mirror network IDs identify spawned network objects in the current session. Re-resolve references after a network object is destroyed or recreated, or after a player reconnects. Fast travel and respawn do not automatically change the ID. A roster entry can temporarily have no loaded `GameObject`; check for null before use, and refresh scene-specific references when their objects change.

### Real-world distance to existing enemies

Mod adapters should not infer a remote enemy's position by subtracting Unity transforms from the observer's `PlayerObject`: separate terrain frames can overlap locally. `TryGetEnemyWorldPosition()` reads the synchronized logical X/Z of an **existing networked exterior enemy** through the public API. Mod code doesn't need to reference the co-op fork's internal world-position component. Use `HorizontalDistance()` to compare it with the local player's `PlayerGPS` world coordinates (40 DF units = 1 Unity metre):

```csharp
MultiplayerWorldPosition enemyWorld;
if (!MultiplayerAPI.TryGetEnemyWorldPosition(deadEnemy, out enemyWorld))
    return; // not networked, not ready, or not an exterior enemy

var gps = GameManager.Instance.PlayerGPS;
var playerWorld = new MultiplayerWorldPosition { WorldX = gps.WorldX, WorldZ = gps.WorldZ };
if (enemyWorld.HorizontalDistance(playerWorld) > 65.0)
    return; // not this player's nearby encounter
```

The returned `Height` is zero because the fork's enemy metadata does not provide a reliable cross-peer height. The method is an **exterior X/Z query only**; interiors/dungeons need their own location identity and local-coordinate rules. It does not grant enemy ownership, prove an event is eligible, or make a server-side distance check: mods must still validate their gameplay-specific navigation/location rules and authority before applying shared changes. An unavailable position causes a `false` result; do not fall back to an observer-relative Unity position for a remote enemy.

## Messages and request handling

Messages carry events or requests. Only the receiver can validate and apply authoritative changes; a successful send does not mean the requested gameplay action was approved.

| API | Direction and use |
| --- | --- |
| `RegisterServerHandler` / `RegisterClientHandler` | Register one binary handler per GUID, channel, and role. |
| `RegisterJsonServerHandler<T>` / `RegisterJsonClientHandler<T>` | Register a `JsonUtility` DTO handler using public serializable fields. |
| `SendToServer` / `SendJsonToServer<T>` | Ready client to server. |
| `SendToPlayer` / `SendJsonToPlayer<T>` | Server to one ready player. |
| `SendToAll` / `SendJsonToAll<T>` | Server to all ready clients, including a local host client. |
| `SendToParty` / `SendJsonToParty<T>` | Server to the ready members of a reference player's party. |
| `UnregisterServerHandler` / `UnregisterClientHandler` | Release a registered message handler. |
| `ToJsonPayload<T>` / `FromJsonPayload<T>` | Convert DTOs to and from UTF-8 bytes. |

`ModMessageContext.SenderPlayerId` is supplied by the transport on server handlers. Validate its eligibility, distance, and rate limits before changing state. The API limits GUIDs to 128 characters, channels to 64, and messages to 32 KiB, with a shared inbound per-connection budget. Use separate channels for discrete requests, replies and transient high-frequency motion when necessary.

```csharp
[Serializable]
public sealed class BellRequest { public int Bell; }

MultiplayerAPI.RegisterJsonServerHandler<BellRequest>(modGuid, "ring", (context, request) =>
{
    if (request == null || !CanRing(context.SenderPlayerId, request.Bell)) return;
    MultiplayerAPI.SendJsonToAll(modGuid, "ring-result", request);
});
```

`CanRing` is a mod-defined permission check. Register the matching client-side `ring-result` handler. Never rely on a client-supplied player ID when the transport already identifies the sender.

## Retained public state

Retained state is suitable for facts that late joiners need (for example, whether a lever was pulled). It is not intended for continuous movement or private inventories. `OpenWorld` already owns its state subscription for the world GUID; use a distinct GUID for an independent retained-state channel.

| API | Purpose |
| --- | --- |
| `SetState(guid, key, payload, ownerId, expectedRevision, out revision)` | Server-only create/update. Revision `0` creates only, `ulong.MaxValue` updates unconditionally, other values compare with current revision. |
| `RemoveState(guid, key, expectedRevision)` | Server-only remove with revision check. |
| `TryGetState(guid, key, out record)` | Server-side read of a defensive copy. |
| `SubscribeState(guid, changed, snapshotComplete)` | Client subscription; both callbacks are required. |
| `RequestStateSnapshot(guid)` | Request the current retained-state snapshot for an active subscription, for example when rebuilding a local view. |
| `UnsubscribeState(guid)` | End the local subscription and clear your own caches. |

`ModStateRecord` contains `Key`, `Revision`, `OwnerPlayerId` and `Payload`. `ModStateChange` indicates `Removed`, `IsSnapshot` and `SnapshotId`; `ModStateSnapshot.Keys` provides the complete set of keys. Reconcile missing keys at snapshot completion, keep deletion revisions, and clear client-side bookkeeping at `SessionEnded`.

```csharp
// Authoritative server only; must follow your mod's request validation.
ulong revision;
MultiplayerAPI.SetState(modGuid, "bridge/open", MultiplayerAPI.ToJsonPayload(new BridgeState { Open = true }),
    0, 0, out revision);

// Subscribe on clients and rebuild the current presentation.
MultiplayerAPI.SubscribeState(modGuid, changed => ApplyRevision(changed),
    snapshot => ReconcileKeys(snapshot.Keys));
```

`BridgeState`, `ApplyRevision` and `ReconcileKeys` are adapter-defined. Global bounds are 2,048 records, 8 MiB of retained payload and 64 subscriptions per process. All retained state is scoped to the active session.

## World objects, encounters and DFU enemies

A **native DFU enemy** is an enemy using Daggerfall Unity's standard enemy components and systems (for example `DaggerfallEntityBehaviour`, `EnemyMotor` and `EnemySenses`), whether created by the base game or by a mod. A **networked DFU enemy** also has the co-op project's Mirror identity and synchronization.

| Call | Purpose |
| --- | --- |
| `Claim(key, callback)` | Reserve a shared event key once per session. Only the first accepted claim succeeds; this does not assign ownership of a GameObject or enemy. |
| `Publish(source, key, kind, data, keepParent, pickable, lifetime, callback)` | Share an independent visual/pickup and bind its original source. |
| `PrepareContainer(loot)` | Immediately mark/gate a session container before automatic exterior discovery. |
| `PublishContainer(...)` | Give an ordinary container a distinct existing LootCatcher transaction ID. |
| `SpawnEnemy(...)` | Server uses the existing normal DFU/co-op enemy spawning path. |
| `ConvertEnemy(existingEnemy, ...)` | Convert an existing, unnetworked DFU enemy to the co-op enemy path. No preliminary local spawn is required. |
| `CreateLocalEnemy(position, options)` | Optionally create an unnetworked DFU enemy if the mod specifically needs to configure a new local enemy before converting it. |
| `UpdateData(key, json)` | Owner updates public presentation/interaction metadata, such as NPC idle state. |
| `Take(key, callback)` | Request pickup of a shared, pickable visual. The server accepts at most one requester; the successful mod callback handles adding the item to inventory. |
| `Remove(key)` | Owner requests shared removal. |
| `ReleaseEnemy(key)` | Release a scripted enemy's persistent ownership and return to normal authority selection. |
| `ResetOwnedObjects()` | Retire the caller's temporary objects and advance its load generation. |

`Claim()` reserves a unique event key so multiple clients cannot independently run the same shared event. It does not transfer object or enemy ownership. Use a distinct key for each distinct event.

`Take()` applies only to shared visual objects published with `pickable: true`. The server checks that the requester is within 4 metres and has not already been beaten to the pickup. On success, the caller receives the record and the mod adds its corresponding inventory item. The API prevents two successful pickup requests; it does not itself grant or roll back inventory items.

`ConvertEnemy()` takes an **existing** living, unnetworked DFU enemy with `SetupDemoEnemy`. It currently supports exterior conversion. `CreateLocalEnemy()` is an independent convenience method, not a prerequisite; use it only when the gameplay mod needs to instantiate a new local enemy. Call `SpawnEnemy()` instead when the mod wants a new enemy created through the co-op networking path.

`ModWorldPose.Capture(transform)` records DF exterior world coordinates at 40
units/metre, or a location identity plus interior-relative position/rotation.
Building/dungeon matching reuses mandatory location metadata, independently of
optional party location sharing. Interior range checks use the creation pose's
player-relative offset in the server's player frame; the server need not load
that room. This trusts the same co-op player position reports as the existing
network system; it is not an anti-cheat protocol.

Default visual radius is 250m (10,000 DF coordinate units). Hiding presentation
also disables its colliders, preserving original enabled states, while leaving
owner scripts running. Hiding/unloading a non-owner replica never removes the
shared source. World origin changes adjust root objects without treating the
origin shift as gameplay movement. Interior objects hide in other locations
and reproject when their owner re-enters a relocated instance of that room.

The final optional argument to `Publish` sets the motion policy. Use
`ModWorldMotion.Fixed` for objects that stay where placed. Use
`ModWorldMotion.Smooth` for moving visuals that benefit from eight pose
updates per second and interpolation between updates. Omitting the argument
uses the default pose update policy.

### Custom object factories

A **factory** is a function registered with `MultiplayerAPI.OpenWorld()` that creates or updates the local GameObject representing a shared world record. The API calls it with the synchronized `ModWorldRecord` and an optional existing GameObject.

- If the existing GameObject is `null`, create a visual representation and return it.
- If an existing visual is supplied, update **that same object** and return it.
- If an existing **networked DFU enemy** is supplied, add or update only the mod's visual and interaction components. The co-op runtime already spawned that enemy; do not spawn a replacement.

The factory can run on multiple clients and more than once for the same record. It must not start encounters, award inventory items, or run gameplay simulation merely because a replica appeared. Use `record.Key` as the identity of the shared object, not its Unity name or distance from another object. Factory exceptions are logged.

This callback has the signature `Func<ModWorldRecord, GameObject, GameObject>`; mods using a built-in appearance still provide a function that returns or creates the appropriate local view.

Networked DFU enemies keep the existing prefab, `NetworkIdentity`, transforms, combat,
interest management and authority. Nonzero `ExteriorRetentionMetres` opts into
the same horizontal retention mechanism used by distant exterior adapters;
zero retains the normal distance policy. `ScriptedOwner` temporarily binds
simulation to the requester until release/despawn. `Transient` defaults true:
these temporary enemies do not serialize as unrelated vanilla enemies.
Networked enemy unloading is Mirror-owned; a client observer disappearing never
requests shared destruction.

Set the native exterior request and retention distances independently:

| Setting | What it controls |
| --- | --- |
| `ExteriorRequestMetres` | Server limit for `SpawnEnemy` and `ConvertEnemy`. Zero uses the 100 m enemy default. Use 1–400 m to override. The limit applies separately to horizontal distance and height difference. |
| `ExteriorRetentionMetres` | Server cleanup radius after spawning. Zero uses the ordinary cleanup policy. Positive values up to 3,000 m use horizontal retention and preserve distant exterior coordinates. |

For distant exterior encounters, let the mod trigger a request at its chosen range and
use the following options. The API handles the supplied enemy when called.
Activation timing and the choice of a shared or player-specific spawn key
belong to the mod.

```csharp
var options = new ModEnemyOptions
{
    ExteriorRequestMetres = 125f,
    ExteriorRetentionMetres = 3000f
};
```

Conversion supports standard DFU enemy type, reaction, gender, ally/team,
current health and exterior pose. When converting an existing enemy, the host/server may reuse its GameObject; a client-local enemy is replaced with a server-spawned network enemy. Conversion does not serialize arbitrary custom components, scripts,
inventories, spell state or custom prefab assets. Add an explicit supported
schema before using conversion for those cases. Initial normal spawn gender
remains selected by the existing normal spawner; conversion preserves its
captured gender. The current-health value becomes the authoritative spawn
health/max through the existing spawn-health helper; conversion of a wounded
enemy does not preserve a separate original maximum-health value.

Containers reuse the existing shared inventory reservation/version protocol.
They have distinct IDs even at identical coordinates. They are gated until
binding completes, and have LoadID=0 to avoid independent vanilla restoration.
The public description and stock snapshot are for ordinary world loot only.
Do not put private quest/party inventories into these records.

## Movement, animation and moving frames

Use `ModWorldMotion.Fixed` for stationary props, `Default` for occasional pose updates, and `Smooth` for continuous visual motion. The world service projects exterior poses across DFU origin shifts and interpolates visual replicas; native enemies use their existing co-op/Mirror movement. Moving-frame support is a separate local step: it carries an independent actor root by the change in pose of a nearby ship, wagon or platform, without modifying `Transform.parent`.

### Independent root movement

The feature moves a *separate scene-root transform* using the change in pose of a
moving reference frame. It never sets the actor's `transform.parent`. Each frame,
its current pose is interpreted against the previous moving frame and reprojected
into the current frame. Thus normal actor motion made earlier in the frame is
preserved:

```
relative = inverse(oldFrameRotation) * (actor.position - originShift - oldFramePosition)
actor.position = newFramePosition + newFrameRotation * relative
actor.rotation = (newFrameRotation * inverse(oldFrameRotation)) * actor.rotation
```

`originShift` is the *difference* of `StreamingWorld.WorldCompensation` since
last sampling. The calculation is intended to run after a source mod's normal
Update/FixedUpdate and after motion-visual interpolation. It is a local movement
helper, **not** a packet serializer, physics engine, or network authority grant.

### Moving-frame public API

| API call | Actor, authorization, interaction |
| --- | --- |
| `MultiplayerAPI.FollowMovingFrame(root, frame, options)` | Caller-controlled independent root. Checks ordinary Mirror authority for networked roots; does not acquire it. Caller stops following by disposing the returned handle. No deck probe. |
| `MultiplayerAPI.FollowEnemyOnMovingFrame(enemyRoot, frame, deck, options)` | Existing registered *native co-op enemy*. Detects feet on deck; optionally requests a temporary persistent owner pin using `ClaimEnemyOwnership`; moves only with real local authority, sends owner context, and releases a pin it acquired at detachment. A pending claim is explicitly cancelled on exit. |
| `MultiplayerAPI.RegisterLocalPlayerMovingSurface(floor, frame, options)` | Registers one solid replica collider that can carry the **local player** when actually standing on it. The player remains unparented and can walk normally. Caller disposes the handle when its replica is destroyed or unregistered. |

All return `ModMovingFrameHandle` (`IDisposable`). Create them on the machine
that owns or displays the relevant objects. They **do not** automatically
replicate their binding to other peers. Each adapter discovers its own local
support and registers it. The surface registration does **not** require any particular mod-specific object synchronization implementation.

### Options (`new ModMovingFrameOptions { ... }`)

- `MaxStepMetres` = `3f`: maximum displacement caused by one rendered platform
  step. Set a larger value for fast-moving ships or `0` to disable the limit;
  a rejected step does **not** teleport the actor. A large correction can
  cause a local-player support to detach instead of being carried.
- `GroundProbeMetres` = `.45f`: maximum feet-to-floor raycast length for
  player support (enemy test also checks character-controller height).
- `LostSupportGraceSeconds` = `.12f`: deck contact grace before releasing
  a network enemy when a grounded test fails. Client interpolation and collision
  timing may require tuning.
- `CarryRotation` = `true`; `KeepPlayerUpright` = `true`: carry yaw/heading with
  the platform while preventing a rotating floor from pitching the player.
- `RequestEnemyOwnership` = `true`; `OwnershipRetrySeconds` = `.75f`;
  `EnemyContextIntervalSeconds` = `.10f`; `MaxEnemyClaimCatchupMetres` = `20f`.
  These govern enemy claims, authority check, periodic location-context updates,
  and bounded catch-up to the initial deck-relative position after the grant.
  `MaxEnemyClaimCatchupMetres=0` disables catch-up.

The moving-frame driver runs at `DefaultExecutionOrder(32000)`, after ordinary movement and late presentation updates. If a mod updates the platform after this order,
that adapter must correct its update order. It uses Physics.SyncTransforms
before probing for contact. Player support also avoids double application
of DFU's normal `PlayerGroundMotor.ActivePlatform` carrying and restores the
original smooth-follower setting on release.

### Examples

See `Examples/MultiplayerAPIMovingFramesExample.cs` for three registration patterns.

**Enemy root supported by a moving surface** — on each owner's local boat, after deck contact is
identified:

```csharp
ModMovingFrameHandle aboard = MultiplayerAPI.FollowEnemyOnMovingFrame(
    networkEnemy, boatMesh.transform, deckCollider,
    new ModMovingFrameOptions { MaxStepMetres = 8f, RequestEnemyOwnership = true });
// On leaving deck, destroying boat, or stopping the adapter:
aboard.Dispose();
```

This operates only on already-networked enemy roots. It does not spawn them,
change their hierarchy, or network the boat itself. The existing native enemy
NetworkTransform distributes the result. If the enemy has another player's
persistent owner, the helper will not steal it. If a different local system
already owns the pin, this handle borrows it and **does not** release that pin.
Only a handle that requested the claim releases or cancels it. Session teardown does not send network commands when transport has ended.

**Moving platform support for the local player** — on the receiver after its wagon
replica, interpolation, and solid collider exist:

```csharp
ModMovingFrameHandle standing = MultiplayerAPI.RegisterLocalPlayerMovingSurface(
    wagonMeshCollider, wagonVisualRoot.transform,
    new ModMovingFrameOptions { MaxStepMetres = 3f });
// Unregister on replica removal or adapter teardown:
standing.Dispose();
```

This handles the local player only. The other player's visible avatar continues
to be synchronized by the usual co-op player stream. Register only **remote
visual replicas**, not the locally controlled source wagon whose own mod may
already implement native player carrying. Do not use two separate movement-carry systems on the same player and surface; they would apply motion twice.

**Independent moving object** — for an independent, locally simulated root:

```csharp
ModMovingFrameHandle following = MultiplayerAPI.FollowMovingFrame(
    separateObjectRoot, movingReferenceRoot);
// Still must publish its own pose with the appropriate multiplayer transport.
following.Dispose();
```


### Scope and lifecycle

A moving-frame handle owns a **local support relationship**, not an extra network position stream. The moving frame must already exist locally. For network actors, only the authority moves the root, and the co-op player/enemy transform stream presents the result to observers. `ModWorldMotion.Smooth` remains the option for separately synchronized visual props.

Dispose the handle when the platform is removed, the actor disembarks, or the adapter shuts down. The API does not serialize moving-frame relationships into saves, spawn a vehicle, or create a gameplay interaction for a replicated prop. Recreate support relationships when objects are rebuilt after travel or load. The gameplay mod retains control of its vehicle movement and other game logic.

## Existing enemy ownership

Call `MultiplayerAPI.ClaimEnemyOwnership(enemy)` on recruitment. Verify the pin with
`TryGetPersistentEnemyOwner(enemy, out playerId)` and check local simulation authority
before moving the actor. Use `PublishOwnedEnemyContext(enemy)` after placement and
location changes, and `ReleaseEnemyOwnership(enemy)` on dismissal to release at the
current pose. This is a session-scoped ownership pin. The mod handles recruitment, gameplay and save data. World-owned scripted enemy pins use `world.ReleaseEnemy(key)` instead.

## Enemy behaviors

Call `world.RegisterEnemyBehavior(id, validate, start)` during initialization
on the server and on every client that can run the behavior. IDs are scoped to
the mod world. The validator receives the authenticated requester ID and the
parameter string. Validate the schema and allowable values before accepting it.
The start callback receives the actual spawned enemy and the validated string.
Return an IDisposable that stops the controller and restores any AI settings
the controller changed. If startup throws, the callback must undo its own
partial setup before throwing.

Set `BehaviorId`, `BehaviorData` and `ScriptedOwner = true` on ModEnemyOptions,
then use SpawnEnemy or ConvertEnemy. Only the ID and parameters cross the wire.
The API starts the locally registered callback once the requester has simulation
authority and the enemy has been bound. It stops the behavior on authority loss,
release or cleanup. A restarted controller receives the original parameters.
Mods that need resume checkpoints should maintain their own progress state.
Use ReleaseEnemy when the scripted behavior is done or combat should resume.
Replicas can still use the existing factory to install local presentation and
interaction components.

## Existing network enemies and combat behavior

These APIs support mods that **modify enemies already spawned and synchronized by co-op**. They do not create, convert or replace enemies. They are distinct from `ModWorld.RegisterEnemyBehavior()`, which controls scripted enemies associated with a `ModWorld` record.

### Lifecycle and behavior registration

| API | Purpose |
| --- | --- |
| `NetworkEnemyReady` | Fires when a regular networked DFU enemy is fully initialized on this peer, including remote clients. |
| `NetworkEnemyAuthorityChanged` | Fires when local simulation authority or the observable owning player changes. |
| `NetworkEnemyRemoved` | Fires before the local enemy is discarded by the API's network-enemy registry. |
| `RegisterExistingEnemyBehavior(id, filter, attach, authorityChanged)` | Applies the adapter's `attach` callback once to each matching **existing** network enemy on the local peer. The callback receives `ModNetworkEnemy` and may return an `IDisposable` cleanup handle. |
| `UnregisterExistingEnemyBehavior(id)` | Stops the registration and disposes its handles. |
| `TryGetNetworkEnemy(netId, out enemy)` | Resolves a fully initialized existing network enemy. |
| `CanSimulateNetworkEnemy(enemyObject)` | Checks native enemy simulation authority, including the host/server fallback. |

`ModNetworkEnemy` provides `NetId`, `GameObject`, `IsSimulationOwner` and `OwnerPlayerId`. A zero owner ID means the server owns the enemy or its remote owning player is unavailable. **`IsSimulationOwner`**, rather than `OwnerPlayerId`, decides whether to run gameplay AI and combat coroutines on this peer. Authority and readiness are checked locally; lifecycle callbacks are polled from actual Mirror-spawned enemies and can occur shortly after a network event, not necessarily in the same frame.

The `filter` should use the enemy's DFU type or other state present on **all peers**, not a gameplay mod component that may only exist on the host. `attach` may install the adapter's missing component on a remote networked enemy, but must not replay global spawn events or call the component's `Start()` manually. The returned handle is disposed when the enemy despawns, the registration is removed or the session ends. An authority-change callback can cancel local routines or switch a component between simulation and presentation. If an enemy's identity is recreated, it receives a fresh attachment. **The API does not copy private mod components, their state, or their attack routines between peers.**

```csharp
// Register on server and clients. Use a filter valid for both owner and observers.
MultiplayerAPI.RegisterExistingEnemyBehavior("my-mod.enemy-behavior",
    enemy => IsSupportedEnemyType(enemy.GameObject),
    enemy => AttachMyInstalledModBehavior(enemy.GameObject, enemy.IsSimulationOwner),
    enemy => UpdateMyBehaviorAuthority(enemy.GameObject, enemy.IsSimulationOwner));

// At mod teardown:
MultiplayerAPI.UnregisterExistingEnemyBehavior("my-mod.enemy-behavior");
```

`IsSupportedEnemyType`, `AttachMyInstalledModBehavior` and `UpdateMyBehaviorAuthority` represent the adapter's code. `AttachMyInstalledModBehavior` returns an `IDisposable` handle; see `Examples/MultiplayerAPIExistingEnemyCombatExample.cs` for a complete generic registration and cleanup pattern.

### Server-validated combat events

| API | Purpose |
| --- | --- |
| `RegisterEnemyCombatChannel(guid, channel, maximumHitDistance, serverCallback, observerCallback)` | Registers a generic combat-event route for a mod. Register it on every peer. |
| `SendEnemyCombatEvent(guid, channel, eventData)` | Sends an attack phase from the **current enemy simulator**; the server checks the request. |
| `UnregisterEnemyCombatChannel(guid, channel)` | Releases the route and its message handlers. |

The `ModEnemyCombatEvent` contains `EnemyNetId`, `Sequence`, `Attack` (a mod-defined maneuver ID), `Phase` and an optional `TargetNetId` for hits. The `ModEnemyCombatPhase` enum provides `Begin`, `Launch`, `Effect`, `Hit`, `End` and `Cancel`. Use a monotonically increasing sequence **per enemy and simulating player** during the session. A different player can take over the enemy with a new sequence counter. Every non-begin phase must belong to an active begin sequence. The server verifies the source's current enemy owner, attack sequence, hit uniqueness for the target and the configured maximum distance. The current attack times out if no further events arrive within 45 seconds.

The `serverCallback` receives an authoritative `ModEnemyCombatContext`, including source and target GameObjects for accepted hits. **The API does not calculate damage or decide whether the attack should succeed.** A mod must still check target life, teams, attack geometry, weapon rules and any gameplay-specific cooldown, then invoke its own damage implementation at the appropriate authority. For hits on players, the adapter can use `SendToPlayer` to route a validated hit to the victim's client. Observer callbacks receive **only visual phases**, never hit requests or permission to apply damage. Visual phases arriving before the remote enemy is ready are queued for up to 3 seconds (maximum 128 pending events per peer).

This reduces the networking boilerplate in compatibility adapters for special enemy attacks without embedding a particular mod's reflection fields, private coroutine layout, leap or charge code, dust effects, or damage formulas in the shared API. An adapter still needs to integrate those gameplay-specific details. See `Examples/MultiplayerAPIExistingEnemyCombatExample.cs`.

## Enemy hierarchy

- Default keeps the existing root spawn and binding behavior.
- Detach explicitly roots the enemy and corrects later reparenting while the
  object is tracked by the API. World position stays fixed on detach.
- Preserve exempts the enemy from the bundled root guard. Attach it to the
  appropriate local parent in the factory or owner controller. The API sends
  the policy, so each peer can resolve its own hierarchy. A host conversion
  restores the original parent after the network spawn. A newly created remote
  enemy starts at root until a local adapter provides its parent.

ApplyEnemyParenting also applies a policy to an existing registered enemy on
the calling peer. For a lasting shared policy on API-spawned enemies, set
ModEnemyOptions.Parenting. Use the bundled root guard when applying these policies. Its public manual exemption remains separate from the API exemption.

## Companion lifecycle

Register a stable, mod-owned root with
`MultiplayerAPI.RegisterCompanionRoot(companionRoot)` before hosting or joining.
Eligible living native enemies under that root are preserved at startup, imported
into co-op, and pinned to the recruiting player. Normal shutdown restores that
player's living pinned companions to local single-player. Remove a companion from
the hierarchy to dismiss it, and unregister the root at mod teardown. The
existing LSO hierarchy rule still works. The same backend supports registered roots
of any name. Follower AI, recruitment, and mod-specific save data belong to the mod.
See the companion lifecycle section in the developer guide.

## World object lifecycle and limits

Shared world records exist for the multiplayer session; they are not a persistent world save format. Owner destruction,
owner disconnect, expiry, load reset, and session end remove temporary objects.
A load reset queues while the transport is unavailable; old owner generations
are rejected after acknowledgement, including delayed requests/snapshots.
Encounter claims remain until session end so a repeated death notification
cannot run the same encounter again. Actual gameplay spawns after a load must
use a new stable event identity if they represent a new event.

Removal tombstones prevent delayed creates from resurrecting consumed keys.
The world service allows 512 lifetime records per mod world (including claims and
tombstones) and shares the 2,048-record / 8 MiB global retained-state store. At the limit new
creates fail explicitly; a new session starts a fresh record budget. Object keys
are at most 64 characters, kinds 48, public data 8192 characters, and the
existing 32KiB message size/rate limits also apply. Request receipts are cached
for the last 4096 operations. These are session bounds, not a long-running persistent object database.

Pickup/placement receipts are reliable, retryable and deduplicated within an
active session. They are not a durable cross-save or cross-disconnect inventory
journal. Avoid disconnecting or loading a save in the middle of an item transfer
when preserving inventory accounting. Rejected placement restores the reserved
item; an interrupted transfer can lose its pending local receipt. Loading an
older player inventory is not a rollback of the shared world or other players'
inventories.

## Examples and integration patterns

- `Examples/MultiplayerAPIExample.cs`: public API initialization and messaging patterns.
- `Examples/MultiplayerAPIStateExample.cs`: retained state and late-join reconciliation.
- `Examples/MultiplayerAPISimpleSyncExample.cs`: mark objects for synchronization, visual prefab registration, automatic pickup and remote moving surfaces.
- `Examples/MultiplayerAPIExistingEnemyCombatExample.cs`: attaching adapters to already-networked enemies and validating combat phases.
- `Examples/MultiplayerAPIMovingFramesExample.cs`: generic boat enemy, wagon passenger and independent root-following registration.
- `Examples/MournersWorkedExample.md`: shared encounter, three flower variants, distinct source lifetimes, loot and DFU enemy integration.

The C# API examples use the `DaggerfallCoop.API` namespace. Methods such as `BuildRoute` and `StartLocalMourningEncounter` are supplied by the gameplay mod.

## Worked example: Mourners

Mourners demonstrates an existing gameplay mod using the multiplayer API. When a humanoid enemy dies in an eligible exterior area, 2-3 civilians, two friendly knights and two friendly mages can approach the corpse, speak when activated, leave offerings and depart (depending on available navigation routes). Every visitor who reaches the offering stage leaves its own one-gold loot container. **One civilian places three independent, pickable flower GameObjects:** a Memorial Red Rose, a Memorial Black Rose and a Memorial Yellow Flower. Each can be picked up directly into inventory and placed back in the world by using its inventory item. A knight or mage attacked by the player can abandon the scripted visit and resume normal combat rather than despawn.

The encounter requires a suitable exterior `CityNavigation` grid, a corpse inside the relevant navigation bounds and reachable routes. The test is not limited by a simple "is town" flag; eligible locations may include some areas near dungeon entrances. Ordinary wilderness without a suitable navigation grid does not qualify. The gameplay mod controls navigation, dialogue, reactions, offerings and item use; the multiplayer adapter synchronizes identities, event claims, world objects, authority and remote presentation.

### Feature mapping

| Mourners behavior | Multiplayer API integration | Gameplay mod responsibility |
| --- | --- | --- |
| One shared encounter per enemy death | Resolve the network enemy ID and its synchronized exterior position with `TryGetEnemyWorldPosition()`, require the real DF-world location to be eligible, then `world.Claim("death/" + enemyId, callback)`. | Determine which deaths qualify and which visitors appear. |
| Three distinct flower GameObjects | Publish the red rose, black rose and yellow flower as **three pickable visuals**, with separate keys and variant data; use `ModWorldMotion.Fixed` while stationary. No `DaggerfallLoot` is involved. | Create each GameObject, collider, visual, interaction component and corresponding item subclass. |
| Flower pickup and placement | `world.Take(key, callback)` allows only one player to take each shared flower; publish a newly placed flower using a fresh key and its correct variant. | Give the matching inventory item on successful pickup and create the new world GameObject when used. |
| Different flower parents and lifetimes | Publish each flower's world pose and stable identity; synchronize removal when its **actual source object** disappears. Original Unity parenting does not automatically replicate. | Keep the red rose under the mod root, the black rose under `StreamingTarget`, and the yellow flower under the current exterior location. |
| Each visitor leaves 1 gold | Prepare and publish each distinct DFU loot container using `ModWorld.PrepareContainer()` and `world.PublishContainer()`. | Generate one gold per visitor after successful arrival. |
| Moving and speaking civilians | Use `ModWorldMotion.Smooth` for civilian visuals; publish relevant mood and dialogue data. Remote replicas present dialogue without running a second gameplay route. | Navigate, determine dialogue and time the visit. |
| Friendly knights and mages | Convert existing unnetworked DFU enemies using `ConvertEnemy`, or directly request new networked enemies with `SpawnEnemy`. Use the enemy behavior/authority API for scripted travel. | Spawn/configure friendly knights and mages and select their routes. |
| Hostility interrupts departure | Release the actor's scripted behavior/ownership and restore combat components without despawning or duplicating the enemy. | Detect attacks, cancel that actor's coroutine and preserve current health and hostility. |
| Late joining or revisiting an area | The API replays relevant live shared records; factories reconstruct remote visuals from stored type and variant data. | Supply visuals/items and persistent storage outside the multiplayer session if required. |

### 1. Start a shared encounter once

Two clients may both observe the same networked enemy die. A death callback should first check that the enemy is synchronized and eligible. The API claim reserves **only an event key**, not the enemy, its corpse or its loot.

```csharp
// Illustrative adapter code; the world, generation and encounter function
// belong to the mod's multiplayer integration.
void OnSyncedDeath(GameObject deadEnemy, Transform groundMarker)
{
    uint enemyId;
    if (!world.Ready || !MultiplayerAPI.TryGetNetworkId(deadEnemy, out enemyId))
        return;

    MultiplayerWorldPosition deathWorld;
    if (!MultiplayerAPI.TryGetEnemyWorldPosition(deadEnemy, out deathWorld))
        return;
    var gps = GameManager.Instance.PlayerGPS;
    var localWorld = new MultiplayerWorldPosition { WorldX = gps.WorldX, WorldZ = gps.WorldZ };
    if (deathWorld.HorizontalDistance(localWorld) > 65.0)
        return;
    // Before claiming, the mod also validates its current navigation location
    // and checks the death's real world X/Z against that location's boundaries.

    ModWorldPose placement = ModWorldPose.Capture(groundMarker);
    string eventKey = "death/" + enemyId;
    int observedGeneration = loadGeneration;
    world.Claim(eventKey, (won, record) =>
    {
        if (!won || observedGeneration != loadGeneration)
            return;

        Vector3 ground;
        Quaternion rotation;
        if (!placement.TryLocal(out ground, out rotation))
            return;

        StartLocalMourningEncounter(eventKey, ground, rotation);
    });
}
```

`StartLocalMourningEncounter` is a gameplay-mod function. The adapter publishes only the actors and offerings actually created. A claimed key remains consumed for the multiplayer session; use a new key for a genuinely new encounter.

### 2. Publish three real flowers and separate gold containers

The three flowers are **independent scene GameObjects**, not loot containers. They each have a collider, click-to-pick-up behavior, inventory item subclass and their own `VisitorLogicalIdentity.ObjectKey`. A single eligible civilian places all three near the corpse, at different offsets. Their item classes are `MemorialRoseItem`, `MemorialBlackRoseItem` and `MemorialYellowFlowerItem`.

| Flower | SP source parent | World positioning and lifetime |
| --- | --- | --- |
| **Memorial Red Rose** | Persistent `FlowerRoot` owned by the Mourners controller | `MemorialFlowerLifetime` maintains its position using DFU world coordinates and floating-origin compensation; hides its renderer/collider while the player is indoors. |
| **Memorial Black Rose** | `GameManager.Instance.StreamingTarget.transform` | Uses the normal streaming-root hierarchy. No custom world-position correction is applied by `MemorialFlowerLifetime`. |
| **Memorial Yellow Flower** | Current exterior location transform (`loc.transform`) | Its object follows that location's lifetime; if a location parent is unavailable, code falls back to `StreamingTarget`. No custom world-position correction is applied. |

All three source flowers have a **30-minute real-time world expiry** and are destroyed when a save load begins; source world objects are not saved/restored. Streaming or location cleanup can remove black and yellow flowers earlier. Inventory items have no corresponding 30-minute expiry. These are properties of the gameplay mod's source objects, **not automatic network-object lifetime rules**: the adapter must track source removal and choose appropriate shared-record lifetimes. In particular, a replica should be identified by its network key, world pose and variant rather than assuming the same Unity parent exists on another client.

```csharp
// Each flower is created by the gameplay mod. Use its real logical key;
// variant metadata lets every client rebuild the matching appearance/item.
world.Publish(redFlower,    eventKey + "/rose/0",          "memorial-flower", "red",
    keepParent: false, pickable: true, lifetimeSeconds: 1800f,
    complete: OnFlowerPublished, motion: ModWorldMotion.Fixed);
world.Publish(blackFlower,  eventKey + "/black-rose/0",    "memorial-flower", "black",
    keepParent: false, pickable: true, lifetimeSeconds: 1800f,
    complete: OnFlowerPublished, motion: ModWorldMotion.Fixed);
world.Publish(yellowFlower, eventKey + "/yellow-flower/0", "memorial-flower", "yellow",
    keepParent: false, pickable: true, lifetimeSeconds: 1800f,
    complete: OnFlowerPublished, motion: ModWorldMotion.Fixed);

// Each visitor has a DIFFERENT normal DFU gold loot container.
ModWorld.PrepareContainer(goldLoot);
world.PublishContainer(goldLoot, eventKey + "/gold/visitor-0", "offering", "",
    lifetimeSeconds: 1800f, complete: OnGoldPublished,
    removeWhenEmpty: true, motion: ModWorldMotion.Fixed);
```

Here `redFlower`, `blackFlower`, `yellowFlower` and `goldLoot` are GameObjects/components found from the gameplay mod; the callbacks are supplied by the adapter. In real integration, prefer the flowers' existing `VisitorLogicalIdentity.ObjectKey` instead of hardcoding `/0`, because the SP script identifies offerings by visitor ordinal. When a flower is picked up, use `world.Take(key, callback)` and grant **that variant's** inventory item only to the successful player. Using it from inventory creates a newly published world object with a fresh key; other flowers remain unaffected.

A custom visual factory uses `record.Kind` and `record.Data` to construct the right flower appearance on remote peers. It does **not** run the SP flower placement function again, grant inventory items or invent a second shared key. `keepParent` controls the source's local parent handling; it does not replicate Unity parent relationships or replace moving-frame behavior.

### 3. Simulate visitors on one authority

Civilians use `Smooth` motion replication for their presentation while one gameplay authority runs their navigation. The two friendly knights and two friendly mages use normal DFU enemy components and the co-op enemy pathway; existing unnetworked enemies can be passed directly to `ConvertEnemy`, while `SpawnEnemy` requests a new synchronized enemy. Register an appropriate behavior before spawning/converting and check `IsAuthoritativeFor(enemy)` before moving an enemy root.

If a knight or mage is struck and becomes hostile, cancel **that actor's** visitor route and planned despawn, restore the combat components disabled for the visit, and release its scripted ownership through `world.ReleaseEnemy(key)`. Keep its existing networked GameObject, current health and pose. The API does not infer a mod's hostility or navigation rules.

### 4. Restore enemy AI after a scripted visit

A scripted behavior should return an `IDisposable` cleanup lease that stops its route and restores only the AI components it changed. This must work when the route completes, the actor becomes hostile, authority changes or the actor disappears.

```csharp
// Example lease owned by the gameplay-mod behavior callback.
sealed class RouteLease : IDisposable
{
    readonly EnemyMotor motor;
    readonly bool previousMotorEnabled;
    readonly Action stopRoute;
    bool disposed;

    public RouteLease(EnemyMotor motor, Action stopRoute)
    {
        this.motor = motor;
        this.stopRoute = stopRoute;
        previousMotorEnabled = motor && motor.enabled;
        if (motor) motor.enabled = false;
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        try { if (stopRoute != null) stopRoute(); }
        finally { if (motor) motor.enabled = previousMotorEnabled; }
    }
}

// In the mod-registered behavior callback. BuildRoute is mod-local.
var route = BuildRoute(enemy, validatedRouteId);
var lease = new RouteLease(enemy.GetComponent<EnemyMotor>(), route.Stop);
try
{
    route.Start();
    return lease;
}
catch
{
    lease.Dispose();
    throw;
}
```

If the route disables `EnemySenses` or `EnemyAttack`, preserve and restore their prior enabled flags too. Do not reset the new hostile/team state when restoring components or destroy the enemy during release.

### 5. Expected multiplayer behavior

- A death observed by host and client produces at most one claimed encounter.
- Every successful visitor offering produces one independently synchronized gold container.
- The designated civilian creates three separate pickable objects: **red rose, black rose and yellow flower**; taking one does not remove the others.
- Each variant retains its appearance and item class when picked up and placed again, with a fresh object key on placement.
- Red, black and yellow flowers preserve their intended **source** positioning/lifetime semantics, including world expiry and removal; the adapter synchronizes those changes rather than copying local Transform parents to remote peers.
- Friendly knights and mages retain normal combat identity when provoked and abandon scripted despawning.
- Late joiners receive the remaining shared objects and actor state without re-running the encounter or duplicating offerings.
- Floating-origin adjustments and changed world/scene references do not create a second instance of a flower.


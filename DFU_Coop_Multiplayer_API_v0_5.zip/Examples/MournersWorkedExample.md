# Mourners - multiplayer integration example

Mourners demonstrates an existing gameplay mod using the multiplayer API. When a humanoid enemy dies in an eligible exterior area, 2-3 civilians, two friendly knights and two friendly mages can approach the corpse, speak when activated, leave offerings and depart (depending on available navigation routes). Every visitor who reaches the offering stage leaves its own one-gold loot container. **One civilian places three independent, pickable flower GameObjects:** a Memorial Red Rose, a Memorial Black Rose and a Memorial Yellow Flower. Each can be picked up directly into inventory and placed back in the world by using its inventory item. A knight or mage attacked by the player can abandon the scripted visit and resume normal combat rather than despawn.

The encounter requires a suitable exterior `CityNavigation` grid, a corpse inside the relevant navigation bounds and reachable routes. The test is not limited by a simple "is town" flag; eligible locations may include some areas near dungeon entrances. Ordinary wilderness without a suitable navigation grid does not qualify. The gameplay mod controls navigation, dialogue, reactions, offerings and item use; the multiplayer adapter synchronizes identities, event claims, world objects, authority and remote presentation.

### Feature mapping

| Mourners behavior | Multiplayer API integration | Gameplay mod responsibility |
| --- | --- | --- |
| One shared encounter per enemy death | Resolve the network enemy ID and synchronized DF-world position with `TryGetEnemyWorldPosition()`, then check real distance and the navigation location before `world.Claim("death/" + enemyId, callback)`. | Determine which deaths qualify and which visitors appear. |
| Three distinct flower GameObjects | Publish the red rose, black rose and yellow flower as **three pickable visuals**, with separate keys and variant data; use `ModWorldMotion.Fixed` while stationary. No `DaggerfallLoot` is involved. | Create each GameObject, collider, visual, interaction component and corresponding item subclass. |
| Flower pickup and placement | `world.Take(key, callback)` allows only one player to take each shared flower; publish a newly placed flower using a fresh key and its correct variant. | Give the matching inventory item on successful pickup and create the new world GameObject when used. |
| Different flower parents and lifetimes | Publish each flower's world pose and stable identity; synchronize removal when its **actual source object** disappears. Original Unity parenting does not automatically replicate. | Keep the red rose under the mod root, the black rose under `StreamingTarget`, and the yellow flower under the current exterior location. |
| Each visitor leaves 1 gold | Prepare and publish each distinct DFU loot container using `ModWorld.PrepareContainer()` and `world.PublishContainer()`. | Generate one gold per visitor after successful arrival. |
| Moving and speaking civilians | Use `ModWorldMotion.Smooth` for civilian visuals; publish relevant mood and dialogue data. Remote replicas present dialogue without running a second gameplay route. | Navigate, determine dialogue and time the visit. |
| Friendly knights and mages | Convert existing unnetworked DFU enemies using `ConvertEnemy`, or directly request new networked enemies with `SpawnEnemy`. Use the enemy behavior/authority API for scripted travel. | Spawn/configure friendly knights and mages and select their routes. |
| Hostility interrupts departure | Release the actor's scripted behavior/ownership and restore combat components without despawning or duplicating the enemy. | Detect attacks, cancel that actor's coroutine and preserve current health and hostility. |
| Late joining or revisiting an area | The API replays relevant live shared records; factories reconstruct remote visuals from stored type and variant data. | Supply visuals/items and persistent storage outside the multiplayer session if required. |

### 1. Start a shared encounter once

Two clients may both observe the same networked enemy die. A death callback should first check that the enemy is synchronized and eligible. The API claim reserves **only an event key**, not the enemy, its corpse or its loot. The claim is not a distance or authority check. Before submitting it, the adapter rejects deaths in other terrain frames using the API's synchronized exterior world coordinates and checks that the death belongs to its actual navigation location. It does not import `EnemyWorldPosition` from the co-op fork.

```csharp
// Illustrative adapter code; the world, generation and encounter function
// belong to the mod's multiplayer integration.
void OnSyncedDeath(GameObject deadEnemy, Transform groundMarker)
{
    uint enemyId;
    if (!world.Ready || !MultiplayerAPI.TryGetNetworkId(deadEnemy, out enemyId))
        return;

    MultiplayerWorldPosition enemyWorld;
    if (!MultiplayerAPI.TryGetEnemyWorldPosition(deadEnemy, out enemyWorld))
        return;
    var gps = GameManager.Instance.PlayerGPS;
    var playerWorld = new MultiplayerWorldPosition { WorldX = gps.WorldX, WorldZ = gps.WorldZ };
    if (enemyWorld.HorizontalDistance(playerWorld) > 65.0)
        return;
    // Also verify enemyWorld lies in this location's navigation bounds.
    // Actual path planning and NPC spawning remain in the SP gameplay mod.

    ModWorldPose placement = ModWorldPose.Capture(groundMarker);
    string eventKey = "death/" + enemyId;
    int observedGeneration = loadGeneration;
    world.Claim(eventKey, (won, record) =>
    {
        if (!won || observedGeneration != loadGeneration)
            return;

        Vector3 ground;
        Quaternion rotation;
        if (!placement.TryLocal(out ground, out rotation))
            return;

        StartLocalMourningEncounter(eventKey, ground, rotation);
    });
}
```

`StartLocalMourningEncounter` is a gameplay-mod function. The adapter publishes only the actors and offerings actually created. A claimed key remains consumed for the multiplayer session; use a new key for a genuinely new encounter.

### 2. Publish three real flowers and separate gold containers

The three flowers are **independent scene GameObjects**, not loot containers. They each have a collider, click-to-pick-up behavior, inventory item subclass and their own `VisitorLogicalIdentity.ObjectKey`. A single eligible civilian places all three near the corpse, at different offsets. Their item classes are `MemorialRoseItem`, `MemorialBlackRoseItem` and `MemorialYellowFlowerItem`.

| Flower | SP source parent | World positioning and lifetime |
| --- | --- | --- |
| **Memorial Red Rose** | Persistent `FlowerRoot` owned by the Mourners controller | `MemorialFlowerLifetime` maintains its position using DFU world coordinates and floating-origin compensation; hides its renderer/collider while the player is indoors. |
| **Memorial Black Rose** | `GameManager.Instance.StreamingTarget.transform` | Uses the normal streaming-root hierarchy. No custom world-position correction is applied by `MemorialFlowerLifetime`. |
| **Memorial Yellow Flower** | Current exterior location transform (`loc.transform`) | Its object follows that location's lifetime; if a location parent is unavailable, code falls back to `StreamingTarget`. No custom world-position correction is applied. |

All three source flowers have a **30-minute real-time world expiry** and are destroyed when a save load begins; source world objects are not saved/restored. Streaming or location cleanup can remove black and yellow flowers earlier. Inventory items have no corresponding 30-minute expiry. These are properties of the gameplay mod's source objects, **not automatic network-object lifetime rules**: the adapter must track source removal and choose appropriate shared-record lifetimes. In particular, a replica should be identified by its network key, world pose and variant rather than assuming the same Unity parent exists on another client.

```csharp
// Each flower is created by the gameplay mod. Use its real logical key;
// variant metadata lets every client rebuild the matching appearance/item.
world.Publish(redFlower,    eventKey + "/rose/0",          "memorial-flower", "red",
    keepParent: false, pickable: true, lifetimeSeconds: 1800f,
    complete: OnFlowerPublished, motion: ModWorldMotion.Fixed);
world.Publish(blackFlower,  eventKey + "/black-rose/0",    "memorial-flower", "black",
    keepParent: false, pickable: true, lifetimeSeconds: 1800f,
    complete: OnFlowerPublished, motion: ModWorldMotion.Fixed);
world.Publish(yellowFlower, eventKey + "/yellow-flower/0", "memorial-flower", "yellow",
    keepParent: false, pickable: true, lifetimeSeconds: 1800f,
    complete: OnFlowerPublished, motion: ModWorldMotion.Fixed);

// Each visitor has a DIFFERENT normal DFU gold loot container.
ModWorld.PrepareContainer(goldLoot);
world.PublishContainer(goldLoot, eventKey + "/gold/visitor-0", "offering", "",
    lifetimeSeconds: 1800f, complete: OnGoldPublished,
    removeWhenEmpty: true, motion: ModWorldMotion.Fixed);
```

Here `redFlower`, `blackFlower`, `yellowFlower` and `goldLoot` are GameObjects/components found from the gameplay mod; the callbacks are supplied by the adapter. In real integration, prefer the flowers' existing `VisitorLogicalIdentity.ObjectKey` instead of hardcoding `/0`, because the SP script identifies offerings by visitor ordinal. When a flower is picked up, use `world.Take(key, callback)` and grant **that variant's** inventory item only to the successful player. Using it from inventory creates a newly published world object with a fresh key; other flowers remain unaffected.

A custom visual factory uses `record.Kind` and `record.Data` to construct the right flower appearance on remote peers. It does **not** run the SP flower placement function again, grant inventory items or invent a second shared key. `keepParent` controls the source's local parent handling; it does not replicate Unity parent relationships or replace moving-frame behavior.

For the flowers, the simpler v0.5 registration interface is another option. Register each flower kind with its local visual prefab and inventory-grant handler on every peer, then mark the original world objects when they appear. A separate GUID such as `modGuid + ".flowers"` keeps the flower sync world distinct from a `ModWorld` used for encounters and enemy behavior. **Use one publication method per flower**; do not call both `world.Publish` and `flowerSync.Register` for the same source.

```csharp
ModSyncWorld flowerSync = MultiplayerAPI.OpenSyncWorld(modGuid + ".flowers");
flowerSync.RegisterPrefab("memorial-red", redPrefab, OnRedRoseTaken);
flowerSync.RegisterPrefab("memorial-black", blackPrefab, OnBlackRoseTaken);
flowerSync.RegisterPrefab("memorial-yellow", yellowPrefab, OnYellowFlowerTaken);

// Call from the mod's actual flower-spawn event, or configure a ModSyncMarker.
flowerSync.Register(redFlower, redKey, "memorial-red",
    new ModSyncOptions { Motion = ModWorldMotion.Fixed,
        Flags = ModSyncFlags.Pickable | ModSyncFlags.AutoPickupOnClick |
                ModSyncFlags.KeepOriginalParent });
```

The three pickup handlers award the corresponding mod item on the winning player's client. Register the other two flower objects in the same way, each with its own key. The gameplay mod still handles flower creation, the three different parent policies, and its own 30-minute source lifetime.

### 3. Simulate visitors on one authority

Civilians use `Smooth` motion replication for their presentation while one gameplay authority runs their navigation. The two friendly knights and two friendly mages use normal DFU enemy components and the co-op enemy pathway; existing unnetworked enemies can be passed directly to `ConvertEnemy`, while `SpawnEnemy` requests a new synchronized enemy. Register an appropriate behavior before spawning/converting and check `IsAuthoritativeFor(enemy)` before moving an enemy root.

If a knight or mage is struck and becomes hostile, cancel **that actor's** visitor route and planned despawn, restore the combat components disabled for the visit, and release its scripted ownership through `world.ReleaseEnemy(key)`. Keep its existing networked GameObject, current health and pose. The API does not infer a mod's hostility or navigation rules.

### 4. Restore enemy AI after a scripted visit

A scripted behavior should return an `IDisposable` cleanup lease that stops its route and restores only the AI components it changed. This must work when the route completes, the actor becomes hostile, authority changes or the actor disappears.

```csharp
// Example lease owned by the gameplay-mod behavior callback.
sealed class RouteLease : IDisposable
{
    readonly EnemyMotor motor;
    readonly bool previousMotorEnabled;
    readonly Action stopRoute;
    bool disposed;

    public RouteLease(EnemyMotor motor, Action stopRoute)
    {
        this.motor = motor;
        this.stopRoute = stopRoute;
        previousMotorEnabled = motor && motor.enabled;
        if (motor) motor.enabled = false;
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        try { if (stopRoute != null) stopRoute(); }
        finally { if (motor) motor.enabled = previousMotorEnabled; }
    }
}

// In the mod-registered behavior callback. BuildRoute is mod-local.
var route = BuildRoute(enemy, validatedRouteId);
var lease = new RouteLease(enemy.GetComponent<EnemyMotor>(), route.Stop);
try
{
    route.Start();
    return lease;
}
catch
{
    lease.Dispose();
    throw;
}
```

If the route disables `EnemySenses` or `EnemyAttack`, preserve and restore their prior enabled flags too. Do not reset the new hostile/team state when restoring components or destroy the enemy during release.

### 5. Expected multiplayer behavior

- A death observed by host and client produces at most one claimed encounter.
- Every successful visitor offering produces one independently synchronized gold container.
- The designated civilian creates three separate pickable objects: **red rose, black rose and yellow flower**; taking one does not remove the others.
- Each variant retains its appearance and item class when picked up and placed again, with a fresh object key on placement.
- Red, black and yellow flowers preserve their intended **source** positioning/lifetime semantics, including world expiry and removal; the adapter synchronizes those changes rather than copying local Transform parents to remote peers.
- Friendly knights and mages retain normal combat identity when provoked and abandon scripted despawning.
- Late joiners receive the remaining shared objects and actor state without re-running the encounter or duplicating offerings.
- Floating-origin adjustments and changed world/scene references do not create a second instance of a flower.

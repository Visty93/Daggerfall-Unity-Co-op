using System;
using System.Collections.Generic;
using System.Collections;
using System.Reflection;
using DaggerfallCoop.API;
using DaggerfallWorkshop;
using DaggerfallWorkshop.Game;
using DaggerfallWorkshop.Game.Serialization;
using DaggerfallWorkshop.Game.Entity;
using DaggerfallWorkshop.Game.Utility;
using DaggerfallWorkshop.Game.Utility.ModSupport;
using DaggerfallWorkshop.Utility;
using DaggerfallConnect;
using DaggerfallConnect.Utility;
using UnityEngine;

namespace CorpseVisitorsSP
{
    // The claimant runs the original encounter. The adapter publishes its products
    // and resumes the original actor controller after native enemy conversion.
    [DefaultExecutionOrder(-10000)]
    public sealed class MournersMPHelper : MonoBehaviour
    {
        internal static ModWorld World;
        static MournersMPHelper instance;
        static readonly FieldInfo FlowerItem = typeof(MemorialRoseWorldObject)
            .GetField("item", BindingFlags.Instance | BindingFlags.NonPublic);
        static readonly FieldInfo Dialogue = typeof(VisitorActor)
            .GetField("dialogue", BindingFlags.Instance | BindingFlags.NonPublic);
        static readonly FieldInfo ActorKnight = typeof(VisitorActor)
            .GetField("knight", BindingFlags.Instance | BindingFlags.NonPublic);

        readonly HashSet<VisitorLogicalIdentity> observed = new HashSet<VisitorLogicalIdentity>();
        readonly Dictionary<MobilePersonNPC, bool> civilians = new Dictionary<MobilePersonNPC, bool>();
        readonly HashSet<uint> pendingDeaths = new HashSet<uint>();
        static readonly MethodInfo OriginalDeath = typeof(MournersMod)
            .GetMethod("OnEnemyDeath", BindingFlags.Instance | BindingFlags.NonPublic);
        static readonly FieldInfo ActorEncounter = typeof(VisitorActor)
            .GetField("encounter", BindingFlags.Instance | BindingFlags.NonPublic);
        static readonly FieldInfo ActorOrdinal = typeof(VisitorActor)
            .GetField("ordinal", BindingFlags.Instance | BindingFlags.NonPublic);
        const string VisitBehavior = "mourner.visit";
        readonly Dictionary<string, NativeVisit> nativeVisits = new Dictionary<string, NativeVisit>();
        EventHandler originalDeath;

        sealed class NativeVisit
        {
            public VisitorEncounter Encounter;
            public List<DFPosition> Route;
            public MournersMod Manager;
            public VisitorActor Actor;
            public int Ordinal;
            public bool Started;
            public GameObject NetworkEnemy;
            public float Deadline;
        }
        bool loading;
        int generation;

        [Invoke(StateManager.StateTypes.Start, 1)]
        public static void Init(InitParams initParams)
        {
            if (instance) return;
            var obj = new GameObject("Mourners MP Helper");
            DontDestroyOnLoad(obj);
            instance = obj.AddComponent<MournersMPHelper>();
            World = MultiplayerAPI.OpenWorld("corpsevisitors.mp.test", instance.CreateReplica);
            World.RegisterEnemyBehavior(VisitBehavior, ValidateVisitKey, instance.ResumeNativeVisit);
            Debug.Log("[MournersMP] Visitor adapter initialized.");
        }

        void Update()
        {
            bool active = MultiplayerAPI.IsActive;
            var root = MournersMod.FlowerRoot;
            if (active && originalDeath == null && root && OriginalDeath != null)
            {
                var manager = root.GetComponent<MournersMod>();
                if (!manager || !manager.enabled) return;
                originalDeath = (EventHandler)Delegate.CreateDelegate(typeof(EventHandler), manager, OriginalDeath);
                EnemyDeath.OnEnemyDeath -= originalDeath;
                EnemyDeath.OnEnemyDeath += ClaimEncounter;
                Debug.Log("[MournersMP] Death listener active, local player=" + MultiplayerAPI.LocalPlayerId);
            }
            else if (!active) RestoreDeathHandler();

            bool nowLoading = SaveLoadManager.Instance != null && SaveLoadManager.Instance.LoadInProgress;
            if ((nowLoading && !loading) || (!active && observed.Count != 0))
            {
                generation++;
                observed.Clear();
                civilians.Clear();
                nativeVisits.Clear();
                pendingDeaths.Clear();
            }
            loading = nowLoading;
            if (!loading && World.Ready) UpdateNativeVisits();
        }

        void RestoreDeathHandler()
        {
            if (originalDeath == null) return;
            EnemyDeath.OnEnemyDeath -= ClaimEncounter;
            var manager = originalDeath.Target as MournersMod;
            if (manager && manager.enabled)
                EnemyDeath.OnEnemyDeath += originalDeath;
            originalDeath = null;
        }

        // The SP code decides whether a corpse has a usable town navigation grid
        // and runs all the original mourning gameplay. This helper only decides
        // whether THIS player is actually near the networked death in DF space.
        // A neighbouring terrain can reuse very similar Unity X/Z coordinates;
        // checking the corpse against PlayerObject.transform.position alone lets
        // an away host claim the client's death and spawn mourners in the host town.
        const double EncounterDistanceMetres = 65.0;

        // Use synchronized DF coordinates where available. This is an exterior-only
        // API query; do not infer the position of an away observer's enemy from
        // raw local Unity X/Z. Missing SyncVars may arrive a few frames later.
        static bool NearActualDeath(EnemyDeath death, DaggerfallLoot corpse, GameManager gm,
            out bool awaitingWorldData, out string reason)
        {
            awaitingWorldData = false;
            reason = null;
            if (!death || !corpse || !gm || gm.PlayerGPS == null || gm.PlayerObject == null ||
                gm.StreamingWorld == null)
            { reason = "death, corpse or local GPS unavailable"; return false; }

            var location = gm.StreamingWorld.CurrentPlayerLocationObject;
            if (!location || !location.GetComponent<CityNavigation>())
            { reason = "no active exterior CityNavigation"; return false; }

            MultiplayerWorldPosition deathPosition;
            if (!MultiplayerAPI.TryGetEnemyWorldPosition(death.gameObject, out deathPosition))
            {
                // There is no trustworthy host-observer fallback. A pure client
                // simulating its own nearby enemy *does* know the local frame;
                // reconstruct it through the API only in that specific case.
                // Server-fallback/host enemies must wait for the synchronized data.
                bool localOwner = MultiplayerAPI.IsClient && !MultiplayerAPI.IsServer &&
                    MultiplayerAPI.IsAuthoritativeFor(death.gameObject);
                if (localOwner && MournersMod.HorizontalDistance(
                    corpse.transform.position, gm.PlayerObject.transform.position) <= EncounterDistanceMetres)
                {
                    deathPosition = MultiplayerWorldPosition.FromLocal(corpse.transform.position,
                        gm.PlayerObject.transform.position, gm.PlayerGPS.WorldX, gm.PlayerGPS.WorldZ,
                        gm.StreamingWorld.WorldCompensation.y);
                }
                else
                {
                    awaitingWorldData = true;
                    reason = "synchronized enemy DF-world position not available yet";
                    return false;
                }
            }

            var playerPosition = new MultiplayerWorldPosition
            {
                WorldX = gm.PlayerGPS.WorldX,
                WorldZ = gm.PlayerGPS.WorldZ
            };
            double distance = deathPosition.HorizontalDistance(playerPosition);
            if (distance > EncounterDistanceMetres)
            {
                reason = "enemy is " + distance.ToString("F1") + "m away in DF coordinates";
                return false;
            }

            // SP's SceneToWorldPosition(corpse) is specific to the local navigation
            // location, so independently verify the enemy's actual DF coordinates
            // belong to that same location before running original gameplay.
            var bounds = location.LocationRect;
            if (deathPosition.WorldX < Math.Min(bounds.left, bounds.right) ||
                deathPosition.WorldX > Math.Max(bounds.left, bounds.right) ||
                deathPosition.WorldZ < Math.Min(bounds.top, bounds.bottom) ||
                deathPosition.WorldZ > Math.Max(bounds.top, bounds.bottom))
            {
                reason = "enemy is outside local CityNavigation world bounds";
                return false;
            }
            return true;
        }

        void ClaimEncounter(object sender, EventArgs args)
        {
            var death = sender as EnemyDeath;
            var gm = GameManager.Instance;
            if (!death || death.GetComponent<VisitorLogicalIdentity>() || !gm ||
                gm.PlayerEnterExit == null || gm.PlayerEnterExit.IsPlayerInside ||
                gm.StreamingWorld == null || gm.PlayerObject == null) return;

            // The SP encounter requires town navigation, even for a local death.
            var location = gm.StreamingWorld.CurrentPlayerLocationObject;
            if (!location || !location.GetComponent<CityNavigation>())
            {
                Debug.Log("[MournersMP] Skipped death: no current exterior CityNavigation (SP restriction).");
                return;
            }
            var entity = death.GetComponent<DaggerfallEntityBehaviour>();
            var corpse = entity ? entity.CorpseLootContainer : null;
            if (!corpse) { Debug.Log("[MournersMP] Skipped death: no corpse marker."); return; }
            uint networkId;
            if (!MultiplayerAPI.TryGetNetworkId(death.gameObject, out networkId))
            {
                Debug.Log("[MournersMP] Skipped death: enemy has no network identity.");
                return;
            }
            if (!pendingDeaths.Add(networkId)) return;
            StartCoroutine(ClaimEncounterWhenReady(sender, args, death, corpse, location, networkId, generation));
        }

        IEnumerator ClaimEncounterWhenReady(object sender, EventArgs args, EnemyDeath death,
            DaggerfallLoot corpse, DaggerfallLocation location, uint networkId, int epoch)
        {
            // SyncVar/startup delivery can lag the death event slightly, especially
            // for a pure client. Never infer a remote location from Unity alone.
            float deadline = Time.unscaledTime + 2.0f;
            string reason = "waiting for API world readiness";
            bool accepted = false;
            while (Time.unscaledTime <= deadline)
            {
                if (!this || epoch != generation || loading || !death || !corpse ||
                    !GameManager.Instance || GameManager.Instance.PlayerEnterExit.IsPlayerInside ||
                    GameManager.Instance.StreamingWorld.CurrentPlayerLocationObject != location)
                {
                    reason = "encounter context changed before claim";
                    break;
                }
                if (!World.Ready) { yield return null; continue; }
                bool awaitingWorldData;
                if (NearActualDeath(death, corpse, GameManager.Instance, out awaitingWorldData, out reason))
                {
                    accepted = true;
                    break;
                }
                if (!awaitingWorldData) break;
                yield return null;
            }
            pendingDeaths.Remove(networkId);
            if (!accepted)
            {
                Debug.Log("[MournersMP] Rejected death " + networkId + ": " + reason);
                yield break;
            }

            Debug.Log("[MournersMP] Requesting encounter claim for nearby death " + networkId);
            World.Claim("death/" + networkId, (won, record) =>
            {
                if (!won)
                {
                    Debug.Log("[MournersMP] Encounter claim not won for enemy " + networkId);
                    return;
                }
                bool stillWaiting;
                string why;
                var gm = GameManager.Instance;
                if (!this || epoch != generation || loading || !death || !corpse ||
                    originalDeath == null || !gm || gm.PlayerEnterExit == null ||
                    gm.PlayerEnterExit.IsPlayerInside || gm.StreamingWorld == null ||
                    gm.StreamingWorld.CurrentPlayerLocationObject != location ||
                    !NearActualDeath(death, corpse, gm, out stillWaiting, out why))
                {
                    Debug.Log("[MournersMP] Won claim but encounter context was no longer valid for " + networkId);
                    return;
                }
                Debug.Log("[MournersMP] Claimed death " + networkId + "; invoking original SP visitor encounter.");
                RunOriginalEncounter(sender, args);
                PublishObjects();
            });
        }

        void RunOriginalEncounter(object sender, EventArgs args)
        {
            // The existing co-op factory consumes one same-frame registration
            // per call. SP currently requests two knights and two mages.
            const int nativeSpawnCalls = 4;
            string caller = typeof(MournersMod).FullName + ".HandleEnemyDeath";
            var slots = new GameObject[nativeSpawnCalls];
            try
            {
                for (int i = 0; i < slots.Length; i++)
                {
                    var slot = new GameObject("Mourners foe staging");
                    slots[i] = slot;
                    var spawner = slot.AddComponent<FoeSpawner>();
                    spawner.enabled = false;
                    spawner.RegisterExternalObjectMode(caller);
                }
                originalDeath(sender, args);
            }
            finally
            {
                foreach (var slot in slots)
                    if (slot) Destroy(slot);
            }
        }

        void LateUpdate()
        {
            if (MultiplayerAPI.IsActive && !loading) PublishObjects();
        }

        void PublishObjects()
        {
            observed.RemoveWhere(id => !id);
            foreach (var id in FindObjectsOfType<VisitorLogicalIdentity>())
            {
                if (observed.Contains(id) || id.GetComponent<ModWorldBinding>() ||
                    id.GetComponent<SharedFlowerPickup>()) continue;
                var flower = id.GetComponent<MemorialRoseWorldObject>();
                observed.Add(id);
                try
                {
                    if (flower) PublishFlower(id, flower);
                    else if (id.Kind == "civilian") PublishCivilian(id);
                    else if (id.Kind == "loot_gold")
                    {
                        var loot = id.GetComponent<DaggerfallLoot>();
                        if (loot) World.PublishContainer(loot, id.ObjectKey, "gold", "", 1800,
                            (ok, record) => { if (!ok && loot) Destroy(loot.gameObject); }, removeWhenEmpty: true, motion: ModWorldMotion.Fixed);
                    }
                    else if ((id.Kind == "allied_knight" || id.Kind == "allied_mage") &&
                        id.GetComponent<VisitorActor>()) TrackNativeVisitor(id);
                }
                catch (Exception error) { Debug.LogError("[MournersMP] Failed adapting " + id.ObjectKey + ": " + error); }
            }

            foreach (var npc in new List<MobilePersonNPC>(civilians.Keys))
            {
                if (!npc) { civilians.Remove(npc); continue; }
                bool idle = npc.Asset && npc.Asset.IsIdle;
                if (idle == civilians[npc] || !World.Ready || !npc.GetComponent<ModWorldBinding>()) continue;
                var id = npc.GetComponent<VisitorLogicalIdentity>();
                World.UpdateData(id.ObjectKey, JsonUtility.ToJson(DescribeCivilian(npc, idle)));
                civilians[npc] = idle;
            }
        }

        void UpdateNativeVisits()
        {
            foreach (var key in new List<string>(nativeVisits.Keys))
            {
                var visit = nativeVisits[key];
                if (visit.Started && visit.Actor && WasProvoked(visit.NetworkEnemy))
                {
                    CancelVisitForCombat(visit);
                    World.ReleaseEnemy(key);
                    nativeVisits.Remove(key);
                }
                else if (visit.Started && !visit.Actor)
                {
                    if (visit.NetworkEnemy) World.ReleaseEnemy(key);
                    else World.Remove(key);
                    nativeVisits.Remove(key);
                }
                else if (!visit.Started && (!visit.Encounter.Navigation ||
                    GameManager.Instance.PlayerEnterExit.IsPlayerInside || Time.unscaledTime >= visit.Deadline))
                {
                    visit.Encounter.Actors.Remove(null);
                    nativeVisits.Remove(key);
                    World.Remove(key);
                }
            }
        }

        static bool WasProvoked(GameObject enemy)
        {
            if (!enemy || !MultiplayerAPI.IsAuthoritativeFor(enemy)) return false;
            var setup = enemy.GetComponent<SetupDemoEnemy>();
            // Co-op's player-provocation path changes this override from PlayerAlly
            // to the creature's normal team. A global hostility flag is insufficient.
            return setup && setup.SpawnTeamOverride >= 0 &&
                setup.SpawnTeamOverride != (int)MobileTeams.PlayerAlly && !setup.AlliedToPlayer;
        }

        static void CancelVisitForCombat(NativeVisit visit)
        {
            var enemy = visit.NetworkEnemy;
            visit.Actor.StopAllCoroutines();
            visit.Encounter.Actors.Remove(visit.Actor);
            foreach (var proxy in enemy.GetComponentsInChildren<VisitorDialogueProxy>(true))
            {
                proxy.Actor = null;
                Destroy(proxy);
            }
            var motor = enemy.GetComponent<EnemyMotor>();
            var senses = enemy.GetComponent<EnemySenses>();
            var attack = enemy.GetComponent<EnemyAttack>();
            if (motor) { motor.IsHostile = true; motor.enabled = true; }
            if (senses) senses.enabled = true;
            if (attack) attack.enabled = true;
            Destroy(visit.Actor);
        }

        static bool ValidateVisitKey(uint player, string key)
        {
            Guid encounter;
            int ordinal;
            if (player == 0 || string.IsNullOrEmpty(key)) return false;
            string[] parts = key.Split('/');
            return parts.Length == 3 && Guid.TryParseExact(parts[0], "N", out encounter) &&
                parts[1] == "visitor" && int.TryParse(parts[2], out ordinal) && ordinal >= 0 && ordinal < 7;
        }

        void TrackNativeVisitor(VisitorLogicalIdentity id)
        {
            var actor = id.GetComponent<VisitorActor>();
            var encounter = actor ? ActorEncounter?.GetValue(actor) as VisitorEncounter : null;
            DFPosition cell;
            List<DFPosition> route;
            if (encounter == null || !encounter.Navigation ||
                !TownGridPath.TryFindNearestWalkable(encounter.Navigation, id.transform.position, 2, out cell) ||
                !TownGridPath.TryRoute(encounter.Navigation, cell, encounter.ApproachCell, out route))
            {
                Destroy(id.gameObject);
                return;
            }
            string key = id.ObjectKey;
            var visit = new NativeVisit { Encounter = encounter, Route = route, Actor = actor,
                Manager = originalDeath?.Target as MournersMod, Ordinal = (int)ActorOrdinal.GetValue(actor),
                Deadline = Time.unscaledTime + 30f };
            nativeVisits.Add(key, visit);
            actor.StopAllCoroutines();
            // Keep the original encounter alive while the owner waits for Mirror.
            encounter.Actors.Remove(actor);
            encounter.Actors.Add(null);
            var options = new ModEnemyOptions
            {
                ScriptedOwner = true, Parenting = ModEnemyParenting.Detach,
                ExteriorRetentionMetres = id.Kind == "allied_mage" ? 3000 : 0,
                BehaviorId = VisitBehavior, BehaviorData = key
            };
            // Preserve the SP visitor's actual dialogue for each network copy.
            // The owner continues to execute the original SP VisitorActor.Begin().
            string spokenText = Dialogue != null ? Dialogue.GetValue(actor) as string : null;
            var relay = id.GetComponent<NativeMournerDialogueRelay>();
            if (!relay) relay = id.gameObject.AddComponent<NativeMournerDialogueRelay>();
            relay.SetDialogue(spokenText);
            World.ConvertEnemy(id.gameObject, key, id.Kind, spokenText ?? string.Empty, options, (ok, record) =>
            {
                if (ok)
                {
                    if (!nativeVisits.ContainsKey(key)) World.Remove(key);
                    return;
                }
                if (nativeVisits.Remove(key)) encounter.Actors.Remove(null);
                if (id) Destroy(id.gameObject);
                Debug.LogWarning("[MournersMP] Native visitor conversion rejected: " + key);
            });
        }

        IDisposable ResumeNativeVisit(GameObject enemy, string key)
        {
            NativeVisit visit;
            if (!nativeVisits.TryGetValue(key, out visit) || !visit.Encounter.Navigation || !visit.Manager ||
                GameManager.Instance.PlayerEnterExit.IsPlayerInside)
                throw new InvalidOperationException("Native visitor's original town is unavailable.");
            var actor = enemy.GetComponent<VisitorActor>();
            if (!actor) actor = enemy.AddComponent<VisitorActor>();
            foreach (var collider in enemy.GetComponentsInChildren<Collider>(true))
            {
                var proxy = collider.GetComponent<VisitorDialogueProxy>();
                if (!proxy) proxy = collider.gameObject.AddComponent<VisitorDialogueProxy>();
                proxy.Actor = actor;
            }
            var motor = enemy.GetComponent<EnemyMotor>();
            var senses = enemy.GetComponent<EnemySenses>();
            var attack = enemy.GetComponent<EnemyAttack>();
            if (motor) motor.enabled = false;
            if (senses) senses.enabled = false;
            if (attack) attack.enabled = false;
            if (!visit.Started) visit.Encounter.Actors.Remove(null);
            visit.Encounter.Actors.Add(actor);
            visit.Actor = actor;
            visit.NetworkEnemy = enemy;
            visit.Started = true;
            actor.Begin(visit.Encounter, visit.Route, visit.Manager, true, visit.Ordinal % 2 == 1, false, visit.Ordinal);
            return new NativeVisitHandle(actor);
        }

        sealed class NativeVisitHandle : IDisposable
        {
            readonly VisitorActor actor;
            public NativeVisitHandle(VisitorActor actor) { this.actor = actor; }
            public void Dispose()
            {
                if (actor)
                {
                    actor.StopAllCoroutines();
                    Destroy(actor);
                }
            }
        }

        [Serializable]
        sealed class CivilianData
        {
            public int Race, Gender, Outfit, Face, FaceRecord;
            public string Name, DialogueText;
            public bool Guard, Idle;
        }

        static CivilianData DescribeCivilian(MobilePersonNPC npc, bool idle)
        {
            return new CivilianData
            {
                Race = (int)npc.Race, Gender = (int)npc.Gender, Outfit = npc.PersonOutfitVariant,
                Face = npc.GetPersonFaceVariant(), FaceRecord = npc.PersonFaceRecordId,
                Name = npc.NameNPC, Guard = npc.IsGuard, Idle = idle,
                DialogueText = Dialogue?.GetValue(npc.GetComponent<VisitorActor>()) as string
            };
        }

        void PublishCivilian(VisitorLogicalIdentity id)
        {
            var npc = id.GetComponent<MobilePersonNPC>();
            if (!npc) return;
            bool idle = npc.Asset && npc.Asset.IsIdle;
            civilians.Add(npc, idle);
            World.Publish(id.gameObject, id.ObjectKey, "civilian", JsonUtility.ToJson(DescribeCivilian(npc, idle)),
                false, false, 180, (ok, record) => { if (!ok && id) Destroy(id.gameObject); }, ModWorldMotion.Smooth);
        }

        void PublishFlower(VisitorLogicalIdentity id, MemorialRoseWorldObject flower)
        {
            var item = FlowerItem?.GetValue(flower) as MemorialRoseItem;
            if (item == null) return;
            int placedGeneration = generation;
            var obj = flower.gameObject;
            var collider = obj.GetComponent<CapsuleCollider>();
            if (collider) collider.enabled = false;
            Destroy(flower);
            var lifetime = obj.GetComponent<MemorialFlowerLifetime>();
            if (lifetime) Destroy(lifetime);
            obj.AddComponent<SharedFlowerPickup>().Item = item;
            World.Publish(obj, id.ObjectKey, "flower", (item.FlowerKind + 1).ToString(),
                item.FlowerKind == 0, true, MemorialFlowerLifetime.WorldLifetimeSeconds,
                (ok, record) =>
                {
                    if (ok) { if (collider) collider.enabled = true; return; }
                    if (!obj) return;
                    bool restore = id && id.EncounterKey == "player-placed" && generation == placedGeneration;
                    Destroy(obj);
                    if (restore && GameManager.Instance && GameManager.Instance.PlayerEntity != null)
                    {
                        var inventory = GameManager.Instance.PlayerEntity.Items;
                        if (!inventory.Contains(item.UID)) inventory.AddItem(item, noStack: true);
                    }
                }, ModWorldMotion.Fixed);
        }

        internal static MemorialRoseItem FlowerVariant(string data)
        {
            switch (data)
            {
                case "1": return new MemorialRoseItem();
                case "2": return new MemorialBlackRoseItem();
                case "3": return new MemorialYellowFlowerItem();
                default: return null;
            }
        }

        GameObject CreateReplica(ModWorldRecord record, GameObject existing)
        {
            if (record.Kind == "flower")
            {
                var item = FlowerVariant(record.Data);
                if (item == null) return null;
                var obj = new GameObject(item.ItemName);
                if (record.KeepParent) obj.transform.SetParent(MournersMod.FlowerRoot, true);
                var collider = obj.AddComponent<CapsuleCollider>();
                collider.radius = .28f;
                collider.height = .82f;
                collider.center = Vector3.up * .41f;
                obj.AddComponent<SharedFlowerPickup>().Item = item;
                obj.AddComponent<MPGroundFlowerSprite>().Attach(item);
                return obj;
            }
            if (record.Kind == "gold")
            {
                var loot = GameObjectHelper.CreateLootContainer(LootContainerTypes.RandomTreasure, InventoryContainerImages.Chest,
                    Vector3.zero, null, DaggerfallLootDataTables.randomTreasureArchive, 20, DaggerfallUnity.NextUID);
                ModWorld.PrepareContainer(loot);
                loot.Items.Clear();
                loot.customDrop = true;
                loot.WorldContext = GameManager.Instance.PlayerEnterExit.WorldContext;
                return loot.gameObject;
            }
            if (record.Type == ModWorldObjectType.NativeEnemy)
            {
                if (existing)
                {
                    if (!existing.GetComponent<VisitorLogicalIdentity>())
                        MournersMod.AddIdentity(existing, record.Key.Split('/')[0], record.Key, record.Kind, 0);
                    // Even non-owners can talk to visible native enemy copies.
                    // Only the simulator runs SP movement, offering and departure.
                    var relay = existing.GetComponent<NativeMournerDialogueRelay>();
                    if (!relay) relay = existing.AddComponent<NativeMournerDialogueRelay>();
                    relay.SetDialogue(record.Data);
                }
                return existing;
            }
            if (record.Kind != "civilian") return null;
            var data = JsonUtility.FromJson<CivilianData>(record.Data);
            var objNpc = existing;
            if (!objNpc)
            {
                objNpc = GameObjectHelper.InstantiatePrefab(DaggerfallUnity.Instance.Option_MobileNPCPrefab.gameObject,
                    "MP CorpseVisitor Civilian", null, Vector3.zero);
                var motor = objNpc.GetComponent<MobilePersonMotor>();
                motor.enabled = false;
                var person = objNpc.GetComponent<MobilePersonNPC>();
                person.Motor = motor;
                person.Asset = motor.MobileAsset;
                person.ApplySyncedPerson((Races)data.Race, (Genders)data.Gender, data.Outfit, data.Guard,
                    data.Face, data.FaceRecord, data.Name);
                foreach (var collider in objNpc.GetComponentsInChildren<Collider>(true)) collider.enabled = false;
                var hitbox = new GameObject("Visitor Dialogue Click Target");
                hitbox.transform.SetParent(objNpc.transform, false);
                hitbox.transform.localPosition = Vector3.up * .9f;
                hitbox.AddComponent<SphereCollider>().radius = .68f;
                var actor = objNpc.AddComponent<VisitorActor>();
                Dialogue?.SetValue(actor, data.DialogueText);
                hitbox.AddComponent<VisitorDialogueProxy>().Actor = actor;
            }
            var npc = objNpc.GetComponent<MobilePersonNPC>();
            if (npc.Asset) npc.Asset.IsIdle = data.Idle;
            return objNpc;
        }

        // Reuse the original VisitorActor.Speak() and VisitorDialogueProxy.Activate()
        // on all network copies. No SP dialogue behavior is duplicated here.
        internal static void EnsureNativeDialogue(GameObject enemy, string text)
        {
            if (!enemy || Dialogue == null || ActorKnight == null || string.IsNullOrEmpty(text)) return;
            var actor = enemy.GetComponent<VisitorActor>();
            if (!actor) actor = enemy.AddComponent<VisitorActor>();
            Dialogue.SetValue(actor, text);
            ActorKnight.SetValue(actor, true);
            foreach (var collider in enemy.GetComponentsInChildren<Collider>(true))
            {
                if (!collider || !collider.enabled) continue;
                var proxy = collider.GetComponent<VisitorDialogueProxy>();
                if (!proxy) proxy = collider.gameObject.AddComponent<VisitorDialogueProxy>();
                proxy.Actor = actor;
            }
        }

        void OnDestroy()
        {
            RestoreDeathHandler();
            if (World != null) World.Dispose();
            World = null;
            instance = null;
        }
    }

    // A networked enemy's colliders may be created/replaced after its world
    // record arrives. Keep the original SP activation proxy on the actual hit
    // colliders, without running another visitor controller on observers.
    internal sealed class NativeMournerDialogueRelay : MonoBehaviour
    {
        string text;
        float nextRefresh;

        internal void SetDialogue(string message)
        {
            text = message;
            nextRefresh = 0f;
        }

        void LateUpdate()
        {
            if (Time.unscaledTime < nextRefresh) return;
            nextRefresh = Time.unscaledTime + 0.3f;
            var binding = GetComponent<ModWorldBinding>();
            if (!binding || binding.Record == null) return;
            if (!binding.Record.ScriptedEnemy)
            {
                var actor = GetComponent<VisitorActor>();
                if (actor)
                {
                    foreach (var proxy in GetComponentsInChildren<VisitorDialogueProxy>(true))
                        if (proxy && proxy.Actor == actor) { proxy.Actor = null; Destroy(proxy); }
                }
                Destroy(this);
                return;
            }
            MournersMPHelper.EnsureNativeDialogue(gameObject, text);
        }
    }

    internal sealed class MPGroundFlowerSprite : MonoBehaviour
    {
        Sprite sprite;

        public void Attach(MemorialRoseItem item)
        {
            Texture2D texture = DaggerfallUnity.Instance.ItemHelper.GetItemImage(item, true).texture;
            if (!texture) return;
            var visual = new GameObject("Memorial flower ground sprite");
            visual.transform.SetParent(transform, false);
            visual.transform.localPosition = Vector3.up * .035f;
            visual.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            sprite = Sprite.Create(texture, new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(.5f, .5f), texture.height / .36f);
            visual.AddComponent<SpriteRenderer>().sprite = sprite;
        }

        void OnDestroy()
        {
            if (sprite) Destroy(sprite);
        }
    }

    public sealed class SharedFlowerPickup : MonoBehaviour, IPlayerActivable
    {
        internal MemorialRoseItem Item;
        bool pending;

        public void Activate(RaycastHit hit)
        {
            var binding = GetComponent<ModWorldBinding>();
            var world = MournersMPHelper.World;
            if (pending || !binding || world == null || hit.distance > 3.5f || GameManager.IsGamePaused) return;
            var original = binding.IsOwner ? Item : null;
            pending = true;
            world.Take(binding.Key, (ok, record) =>
            {
                if (!ok) { if (this) pending = false; return; }
                var item = original ?? MournersMPHelper.FlowerVariant(record.Data);
                if (item == null || !GameManager.Instance || GameManager.Instance.PlayerEntity == null) return;
                GameManager.Instance.PlayerEntity.Items.AddItem(item, noStack: true);
                DaggerfallUI.Instance.PopupMessage("You pick up the " + item.ItemName + ".");
            });
        }
    }
}

// Mourners SP - experimental Daggerfall Unity single-player test mod.
// Source only: add to DFU's Unity Mod Builder.
// Uses DFU's native civilian MobilePersonNPC prefab and CityNavigation grid.
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DaggerfallWorkshop;
using DaggerfallWorkshop.Game;
using DaggerfallWorkshop.Game.Entity;
using DaggerfallWorkshop.Game.Items;
using DaggerfallWorkshop.Game.Serialization;
using DaggerfallWorkshop.Game.Utility;
using DaggerfallWorkshop.Game.Utility.ModSupport;
using DaggerfallWorkshop.Utility;
using DaggerfallConnect;
using DaggerfallConnect.Utility;

namespace CorpseVisitorsSP
{
    // Tracks visitor type and offering identity, and prevents recursive mourning events.
    public sealed class VisitorLogicalIdentity : MonoBehaviour
    {
        public string EncounterKey;
        public string ObjectKey;
        public string Kind;
        public ulong OriginEnemyLoadId;
    }

    public sealed class MournersMod : MonoBehaviour
    {
        public const string ModGuid = "corpsevisitors.sp.test";
        const int MinVisitors = 2;
        const int MaxVisitors = 3;
        const int MinKnights = 2;
        const int MaxKnights = 2;
        const int MageVisitors = 2;
        const int MaxSimultaneousEncounters = 3;
        const float MinimumSpawnDistance = 15.5f;
        const float MaximumSpawnDistance = 21.5f;

        static Mod mod;
        internal static Transform FlowerRoot;
        readonly List<VisitorEncounter> encounters = new List<VisitorEncounter>();

        [Invoke(StateManager.StateTypes.Start, 0)]
        public static void Init(InitParams initParams)
        {
            mod = initParams.Mod;
            GameObject go = new GameObject("Mourners");
            DontDestroyOnLoad(go);
            FlowerRoot = go.transform;
            go.AddComponent<MournersMod>();
            // The inventory subclass is stored in saves via ItemData_v1.className.
            // Temporary flower world GameObjects are NOT saved/restored.
            // Register before any item is deserialized during load.
            ItemCollection.RegisterCustomItem(typeof(MemorialRoseItem).ToString(), typeof(MemorialRoseItem));
            ItemCollection.RegisterCustomItem(typeof(MemorialBlackRoseItem).ToString(), typeof(MemorialBlackRoseItem));
            ItemCollection.RegisterCustomItem(typeof(MemorialYellowFlowerItem).ToString(), typeof(MemorialYellowFlowerItem));
            mod.IsReady = true;
            Debug.Log("[MournersSP] Started. Civilian visitor events require an outdoor town with CityNavigation.");
        }

        void OnEnable() { EnemyDeath.OnEnemyDeath += OnEnemyDeath; }
        void OnDisable() { EnemyDeath.OnEnemyDeath -= OnEnemyDeath; }

        void Update()
        {
            // F9 is a quick way to prove that the mod has initialized and remains active.
            if (Input.GetKeyDown(KeyCode.F9))
            {
                string state = "mod active";
                if (GameManager.Instance != null && GameManager.Instance.PlayerEnterExit != null)
                {
                    if (GameManager.Instance.PlayerEnterExit.IsPlayerInside)
                        state = "inside: no outdoor visitors";
                    else
                    {
                        var currentLocation = GameManager.Instance.StreamingWorld.CurrentPlayerLocationObject;
                        var nav = currentLocation ? currentLocation.GetComponent<CityNavigation>() : null;
                        state = nav ? "outdoors: town navigation found" : "outdoors: no town navigation here";
                    }
                }
                Report("F9 check - " + state);
            }
            // Town NPC navigation is local to the loaded exterior. Never keep actors
            // walking inside an unloaded city or after entering a building/dungeon.
            if (GameManager.Instance != null && GameManager.Instance.PlayerEnterExit != null &&
                GameManager.Instance.PlayerEnterExit.IsPlayerInside && encounters.Count > 0)
                ClearAllEncounters();

            for (int i = encounters.Count - 1; i >= 0; --i)
                if (encounters[i].Actors.Count == 0)
                    encounters.RemoveAt(i);
        }

        void OnDestroy() { ClearAllEncounters(); }

        static void Report(string message)
        {
            // Operational details stay in the log, not on the player's screen.
            Debug.Log("[MournersSP] " + message);
        }

        void OnEnemyDeath(object sender, EventArgs args)
        {
            Debug.Log("[MournersSP] EnemyDeath.OnEnemyDeath received.");
            try { HandleEnemyDeath(sender, args); }
            catch (Exception ex) { Debug.LogError("[MournersSP] Failed handling death: " + ex); Report("Death handler error - inspect log"); }
        }

        void HandleEnemyDeath(object sender, EventArgs args)
        {
            // Event is raised only once the normal corpse loot marker has been created.
            EnemyDeath dead = sender as EnemyDeath;
            if (!dead) { Report("Skipped: invalid death event sender"); return; }
            if (GameManager.Instance == null || GameManager.Instance.PlayerEnterExit == null)
            { Report("Skipped: game/player world not initialized"); return; }
            if (GameManager.Instance.PlayerEnterExit.IsPlayerInside)
            { Report("Skipped: inside a building or dungeon (town exterior only)"); return; }
            if (encounters.Count >= MaxSimultaneousEncounters)
            { Report("Skipped: already running 3 encounters"); return; }

            // Don't create recursive funeral events when the player attacks one of our knights.
            if (dead.GetComponent<VisitorLogicalIdentity>()) return;
            DaggerfallEntityBehaviour eb = dead.GetComponent<DaggerfallEntityBehaviour>();
            EnemyEntity enemy = eb != null ? eb.Entity as EnemyEntity : null;
            if (enemy == null) { Report("Skipped: dead object has no EnemyEntity"); return; }
            if (!IsHumanoid(enemy)) { Report("Skipped: enemy is not humanoid"); return; }

            DaggerfallLoot corpse = eb.CorpseLootContainer;
            if (!corpse) { Report("Skipped: corpse loot marker not available"); return; }

            var loc = GameManager.Instance.StreamingWorld.CurrentPlayerLocationObject;
            CityNavigation navigation = loc ? loc.GetComponent<CityNavigation>() : null;
            if (!navigation)
            { Report("Skipped: no town CityNavigation - are you in town streets?"); return; }
            if (!DaggerfallUnity.Instance.Option_MobileNPCPrefab)
            { Report("Skipped: civilian prefab missing"); return; }

            if (HorizontalDistance(GameManager.Instance.PlayerObject.transform.position, corpse.transform.position) > 65f)
            { Report("Skipped: corpse is more than 65m from player"); return; }
            // Do not silently clamp a corpse outside town to a cell on the edge.
            DFPosition worldPos;
            try { worldPos = navigation.SceneToWorldPosition(corpse.transform.position); }
            catch (Exception ex) { Report("Skipped: cannot convert corpse position - " + ex.Message); return; }
            var rect = loc.LocationRect;
            if (worldPos.X < Mathf.Min(rect.left, rect.right) || worldPos.X > Mathf.Max(rect.left, rect.right) ||
                worldPos.Y < Mathf.Min(rect.top, rect.bottom) || worldPos.Y > Mathf.Max(rect.top, rect.bottom))
            { Report("Skipped: corpse outside town navigation boundary"); return; }

            VisitorEncounter encounter = new VisitorEncounter();
            encounter.Key = Guid.NewGuid().ToString("N");
            encounter.Navigation = navigation;
            encounter.Corpse = corpse.transform;
            encounter.Origin = corpse.transform.position;
            DaggerfallEnemy dfEnemy = dead.GetComponent<DaggerfallEnemy>();
            encounter.EnemyLoadId = dfEnemy ? dfEnemy.LoadID : 0UL;
            encounter.Parent = loc.transform;

            DFPosition goal;
            if (!TownGridPath.TryFindNearestWalkable(navigation, encounter.Origin, 5, out goal))
            { Report("Skipped: no walkable town tile near corpse"); return; }
            encounter.ApproachCell = goal;

            // Each spawned visitor gets its own route, dialogue and item drop.
            int civilians = UnityEngine.Random.Range(MinVisitors, MaxVisitors + 1);
            int knights = UnityEngine.Random.Range(MinKnights, MaxKnights + 1);
            int createdCivilians = 0;
            bool gaveFlower = false;
            for (int i = 0; i < civilians + knights + MageVisitors; ++i)
            {
                bool knight = i >= civilians; // Shared native-enemy actor behavior for knights AND mages.
                bool mage = i >= civilians + knights;
                DFPosition startCell;
                List<DFPosition> route;
                if (!FindSpawnRoute(encounter, out startCell, out route))
                {
                    Debug.LogWarning("[MournersSP] No route for visitor " + i);
                    continue;
                }
                GameObject visitor = null;
                try
                {
                    if (knight)
                    {
                        GameObject[] foes = GameObjectHelper.CreateFoeGameObjects(
                            TownGridPath.CellPosition(navigation, startCell), mage ? MobileTypes.Mage : MobileTypes.Knight, 1,
                            MobileReactions.Passive, null, true);
                        if (foes == null || foes.Length == 0 || !foes[0])
                            throw new Exception("CreateFoeGameObjects returned no enemy visitor.");
                        visitor = foes[0];
                        visitor.name = (mage ? "CorpseVisitor Friendly Mage " : "CorpseVisitor Friendly Knight ") + i;
                        visitor.transform.SetParent(encounter.Parent, true);
                        // Keep native enemy damage/character colliders intact. Temporarily
                        // disable AI while route-following; restore on hostility.
                        var enemyMotor = visitor.GetComponent<EnemyMotor>();
                        if (enemyMotor) enemyMotor.enabled = false;
                        var enemySenses = visitor.GetComponent<EnemySenses>();
                        if (enemySenses) enemySenses.enabled = false;
                        var enemyAttack = visitor.GetComponent<EnemyAttack>();
                        if (enemyAttack) enemyAttack.enabled = false;
                    }
                    else
                    {
                        visitor = GameObjectHelper.InstantiatePrefab(
                            DaggerfallUnity.Instance.Option_MobileNPCPrefab.gameObject,
                            "CorpseVisitor Civilian " + i, encounter.Parent,
                            TownGridPath.CellPosition(navigation, startCell));
                        MobilePersonMotor motor = visitor.GetComponent<MobilePersonMotor>();
                        MobilePersonNPC person = visitor.GetComponent<MobilePersonNPC>();
                        if (!motor || !person)
                            throw new Exception("Civilian prefab missing its person or motor.");
                        motor.enabled = false;
                        motor.cityNavigation = navigation;
                        person.Motor = motor;
                        person.Asset = motor.MobileAsset;
                        person.RandomiseNPC(Races.Breton);
                        GameObjectHelper.AlignBillboardToGround(visitor, new Vector2(0, 2f));
                        if (person.Asset) person.Asset.IsIdle = false;
                    }

                    bool happy = (i % 2 == 1);
                    bool dropsFlower = !knight && !gaveFlower;
                    if (dropsFlower) gaveFlower = true;
                    if (!knight) createdCivilians++;
                    VisitorLogicalIdentity id = visitor.AddComponent<VisitorLogicalIdentity>();
                    id.EncounterKey = encounter.Key;
                    id.ObjectKey = encounter.Key + "/visitor/" + i;
                    id.Kind = mage ? "allied_mage" : knight ? "allied_knight" : "civilian";
                    id.OriginEnemyLoadId = encounter.EnemyLoadId;

                    // Keep ALL of the knight's real hit colliders. They must be
                    // damageable so DFU can turn them hostile after player attacks.
                    // Citizens continue using the original custom click target.
                    VisitorActor actor = visitor.AddComponent<VisitorActor>();
                    if (knight)
                    {
                        // DFU checks IPlayerActivable on the EXACT collider hit.
                        // Attach to the existing collider objects without changing
                        // their layers, enabling or blocking normal enemy combat.
                        foreach (Collider original in visitor.GetComponentsInChildren<Collider>(true))
                        {
                            if (!original || !original.enabled) continue;
                            var click = original.gameObject.GetComponent<VisitorDialogueProxy>();
                            if (!click) click = original.gameObject.AddComponent<VisitorDialogueProxy>();
                            click.Actor = actor;
                        }
                    }
                    else
                    {
                        foreach (Collider original in visitor.GetComponentsInChildren<Collider>(true))
                            original.enabled = false;
                        GameObject hitbox = new GameObject("Visitor Dialogue Click Target");
                        hitbox.transform.SetParent(visitor.transform, false);
                        hitbox.transform.localPosition = new Vector3(0f, 0.9f, 0f);
                        SphereCollider sphere = hitbox.AddComponent<SphereCollider>();
                        sphere.radius = 0.68f;
                        hitbox.AddComponent<VisitorDialogueProxy>().Actor = actor;
                    }
                    encounter.Actors.Add(actor);
                    // Activate after adding marker to exclude funeral recursion.
                    if (!visitor.activeSelf) visitor.SetActive(true);
                    actor.Begin(encounter, route, this, knight, happy, dropsFlower, i);
                    Debug.Log("[MournersSP] Spawned " + id.ObjectKey + " nodes=" + route.Count);
                }
                catch (Exception ex)
                {
                    Report("Visitor spawn failed: " + ex.Message);
                    if (visitor) Destroy(visitor);
                }
            }
            if (encounter.Actors.Count > 0)
            {
                encounters.Add(encounter);
                Report("Spawned " + encounter.Actors.Count + " visitors (" +
                       createdCivilians + " civilians, remainder allied knights/mages)");
            }
            else Report("Skipped: no valid visitor spawn/path found around corpse");
        }

        static bool IsHumanoid(EnemyEntity enemy)
        {
            // Includes human enemy classes, orc ranks, humanoid undead and vampires.
            // Nonhumanoid monsters (rats, bears, spiders, etc.) are deliberately ignored.
            if (enemy.EntityType == EntityTypes.EnemyClass)
                return true;
            MobileTypes type = (MobileTypes)enemy.MobileEnemy.ID;
            switch (type)
            {
                case MobileTypes.Orc:
                case MobileTypes.OrcSergeant:
                case MobileTypes.OrcShaman:
                case MobileTypes.OrcWarlord:
                case MobileTypes.SkeletalWarrior:
                case MobileTypes.Zombie:
                case MobileTypes.Mummy:
                case MobileTypes.Vampire:
                case MobileTypes.VampireAncient:
                    return true;
                default:
                    return false;
            }
        }

        static bool FindSpawnRoute(VisitorEncounter e, out DFPosition start, out List<DFPosition> route)
        {
            start = new DFPosition(-1, -1);
            route = null;
            // 1 town-nav tile ~1.6 m. Sample a ring ~16-22 m from the corpse.
            for (int attempt = 0; attempt < 28; ++attempt)
            {
                float angle = UnityEngine.Random.Range(0f, Mathf.PI * 2f);
                float range = UnityEngine.Random.Range(MinimumSpawnDistance, MaximumSpawnDistance);
                Vector3 sample = e.Origin + new Vector3(Mathf.Cos(angle) * range, 0, Mathf.Sin(angle) * range);
                DFPosition cell;
                if (!TownGridPath.TryFindNearestWalkable(e.Navigation, sample, 1, out cell))
                    continue;
                Vector3 pos = TownGridPath.CellPosition(e.Navigation, cell);
                if (HorizontalDistance(pos, e.Origin) < MinimumSpawnDistance - 1.5f)
                    continue;
                List<DFPosition> planned;
                if (TownGridPath.TryRoute(e.Navigation, cell, e.ApproachCell, out planned) && planned.Count > 2)
                {
                    start = cell;
                    route = planned;
                    return true;
                }
            }
            return false;
        }

        internal static float HorizontalDistance(Vector3 a, Vector3 b)
        {
            float x = a.x - b.x, z = a.z - b.z;
            return Mathf.Sqrt(x * x + z * z);
        }

        internal void LeaveOffering(VisitorEncounter e, VisitorActor actor, Vector3 position, bool flower, int ordinal)
        {
            // Each visitor leaves a normal DFU one-gold loot pile. One civilian
            // also creates a NEW independent Unity GameObject for the rose.
            try
            {
                Vector3 ground = position - Vector3.up;
                DaggerfallLoot loot = GameObjectHelper.CreateLootContainer(
                    LootContainerTypes.DroppedLoot, InventoryContainerImages.Chest, ground,
                    GameManager.Instance.StreamingTarget.transform,
                    DaggerfallLootDataTables.randomTreasureArchive, 20, DaggerfallUnity.NextUID);
                loot.customDrop = true;
                loot.playerOwned = false;
                loot.WorldContext = GameManager.Instance.PlayerEnterExit.WorldContext;
                loot.Items.AddItem(ItemBuilder.CreateGoldPieces(1));
                AddIdentity(loot.gameObject, e.Key, e.Key + "/gold/" + ordinal,
                    "loot_gold", e.EnemyLoadId);
                GameManager.Instance.StreamingWorld.TrackLooseObject(loot.gameObject, true);
                Debug.Log("[MournersSP] Visitor " + ordinal + " left 1 gold.");
            }
            catch (Exception ex) { Debug.LogError("[MournersSP] Failed gold drop: " + ex); }
            if (flower)
            {
                PlaceMemorialRose(position - Vector3.up + Vector3.right * 0.8f,
                    e.Key, e.Key + "/rose/" + ordinal, e.EnemyLoadId, new MemorialRoseItem());
                PlaceMemorialRose(position - Vector3.up + Vector3.right * 1.6f,
                    e.Key, e.Key + "/black-rose/" + ordinal, e.EnemyLoadId, new MemorialBlackRoseItem());
                PlaceMemorialRose(position - Vector3.up + Vector3.right * 2.4f,
                    e.Key, e.Key + "/yellow-flower/" + ordinal, e.EnemyLoadId, new MemorialYellowFlowerItem());
            }
        }

        internal static void AddIdentity(GameObject obj, string encounterKey, string key, string kind, ulong originId)
        {
            VisitorLogicalIdentity id = obj.GetComponent<VisitorLogicalIdentity>();
            if (!id) id = obj.AddComponent<VisitorLogicalIdentity>();
            id.EncounterKey = encounterKey;
            id.ObjectKey = key;
            id.Kind = kind;
            id.OriginEnemyLoadId = originId;
        }

        // This is a real, independently spawned Unity GameObject, NOT a DaggerfallLoot
        // container. Both placing and picking up mutate the object lifecycle itself.
        internal static bool PlaceMemorialRose(Vector3 approxGround, string encounterKey, string key,
            ulong originId, MemorialRoseItem existingItem = null)
        {
            GameObject obj = null;
            try
            {
                if (GameManager.Instance == null || GameManager.Instance.PlayerEnterExit == null ||
                    GameManager.Instance.PlayerEnterExit.IsPlayerInside)
                    return false;

                Vector3 ground;
                if (!TryFindFlowerGround(approxGround, out ground))
                    return false;

                var roseItem = existingItem ?? new MemorialRoseItem();
                // Each flower variant uses its own parenting policy.
                var loc = GameManager.Instance.StreamingWorld.CurrentPlayerLocationObject;
                Transform parent = loc ? loc.transform : GameManager.Instance.StreamingTarget.transform;
                if (roseItem.FlowerKind == 0)
                {
                    if (!FlowerRoot) throw new Exception("Mourners root is unavailable.");
                    parent = FlowerRoot;
                }
                else if (roseItem.FlowerKind == 1)
                    parent = GameManager.Instance.StreamingTarget.transform;
                obj = new GameObject(roseItem.ItemName);
                obj.transform.SetParent(parent, true);
                obj.transform.position = ground;
                obj.layer = 0;
                AddIdentity(obj, encounterKey, key, "memorial_flower_" + roseItem.FlowerKind, originId);

                var collider = obj.AddComponent<CapsuleCollider>();
                collider.isTrigger = false;
                collider.radius = 0.28f;
                collider.height = 0.82f;
                collider.center = new Vector3(0f, 0.41f, 0f);

                MemorialRoseWorldObject component = obj.AddComponent<MemorialRoseWorldObject>();
                component.SetItem(roseItem);
                FlowerModel.Attach(obj, roseItem);
                obj.AddComponent<MemorialFlowerLifetime>().Begin(roseItem.FlowerKind == 0);
                Debug.Log("[MournersSP] Spawned independent Memorial Rose world object " + key +
                    " itemUID=" + component.ItemUID);
                return true;
            }
            catch (Exception ex)
            {
                Debug.LogError("[MournersSP] Independent Memorial Rose spawn failed: " + ex);
                if (obj) Destroy(obj);
                return false;
            }
        }

        // Test whether the target is actual walkable ground (not an enemy,
        // player, loot pile, another rose, or a steep building wall).
        internal static bool TryFindFlowerGround(Vector3 approximate, out Vector3 result)
        {
            result = Vector3.zero;
            RaycastHit[] hits = Physics.RaycastAll(approximate + Vector3.up * 2.5f,
                Vector3.down, 6.5f, ~0, QueryTriggerInteraction.Ignore);
            float nearest = float.MaxValue;
            foreach (RaycastHit hit in hits)
            {
                Collider c = hit.collider;
                if (!c || hit.distance >= nearest || hit.normal.y < 0.76f ||
                    Mathf.Abs(hit.point.y - approximate.y) > 1.35f) continue;
                if (c.GetComponentInParent<DaggerfallEntityBehaviour>() ||
                    c.GetComponentInParent<DaggerfallLoot>() ||
                    c.GetComponentInParent<MemorialRoseWorldObject>() ||
                    c.GetComponentInParent<PlayerMotor>()) continue;
                nearest = hit.distance;
                result = hit.point;
            }
            return nearest < float.MaxValue;
        }

        internal void ActorFinished(VisitorEncounter e, VisitorActor actor)
        {
            e.Actors.Remove(actor);
        }

        void ClearAllEncounters()
        {
            for (int i = 0; i < encounters.Count; ++i)
            {
                foreach (VisitorActor actor in encounters[i].Actors)
                    if (actor) Destroy(actor.gameObject);
                encounters[i].Actors.Clear();
            }
            encounters.Clear();
            // Deliberately do NOT destroy dropped loot: it belongs to DFU's loot/save system.
        }
    }

    internal sealed class VisitorEncounter
    {
        public string Key;
        public ulong EnemyLoadId;
        public CityNavigation Navigation;
        public Transform Corpse;
        public Vector3 Origin;
        public Transform Parent;
        public DFPosition ApproachCell;

        public readonly List<VisitorActor> Actors = new List<VisitorActor>();
    }

    public sealed class VisitorActor : MonoBehaviour
    {
        VisitorEncounter encounter;
        MournersMod root;
        MobilePersonNPC npc;
        bool knight;
        bool cheerful;
        bool leaveRose;
        int ordinal;
        string dialogue;
        bool completedLastRoute;
        bool releasedFromMourning;
        EnemyMotor enemyMotor;
        EnemySenses enemySenses;
        EnemyAttack enemyAttack;
        const float Speed = 1.65f;

        internal void Begin(VisitorEncounter e, List<DFPosition> approachRoute, MournersMod manager, bool knightActor, bool isCheerful, bool rose, int index)
        {
            encounter = e;
            root = manager;
            npc = GetComponent<MobilePersonNPC>();
            knight = knightActor;
            if (knight)
            {
                enemyMotor = GetComponent<EnemyMotor>();
                enemySenses = GetComponent<EnemySenses>();
                enemyAttack = GetComponent<EnemyAttack>();
            }
            cheerful = isCheerful;
            leaveRose = rose;
            ordinal = index;
            string[] sad = { "How tragic. No one deserved such an end.",
                "May the gods show mercy to the departed.", "A life ended on these streets..." };
            string[] glad = { "Good riddance. It was about time.",
                "The city will sleep easier tonight.", "Some deaths are hardly a loss." };
            dialogue = (cheerful ? glad : sad)[index % 3];
            StartCoroutine(Lifetime(approachRoute));
        }

        void Update()
        {
            // DFU's HandleAttackFromSource() calls MakeEnemyHostileToAttacker()
            // even while EnemyMotor's own MonoBehaviour update is disabled.
            // It turns the attacked knight's player-ally team back to normal.
            // DFU's MakeEnemiesHostile() also sets IsHostile on ALL active
            // enemies when a passive enemy is struck. Only release the mourner
            // whose senses explicitly target the attacking PLAYER, not all
            // neighboring passive knights merely flagged by that global call.
            if (!releasedFromMourning && knight && enemyMotor && enemyMotor.IsHostile &&
                enemySenses && GameManager.Instance &&
                enemySenses.Target == GameManager.Instance.PlayerEntityBehaviour)
                ReleaseHostileKnight();
        }

        void ReleaseHostileKnight()
        {
            if (releasedFromMourning) return;
            releasedFromMourning = true;
            StopAllCoroutines(); // no more offerings, departure or scripted despawn
            if (root) root.ActorFinished(encounter, this);

            foreach (VisitorDialogueProxy proxy in GetComponentsInChildren<VisitorDialogueProxy>(true))
            {
                proxy.Actor = null;
                Destroy(proxy);
            }
            // The original knight's damage colliders were never disabled.
            // Restore native enemy AI, sensing and attacks on this same object.
            if (enemySenses) enemySenses.enabled = true;
            if (enemyAttack) enemyAttack.enabled = true;
            if (enemyMotor) enemyMotor.enabled = true;
            Debug.Log("[MournersSP] Mourner knight hit: cancelled departure/despawn, restored AI. " + gameObject.name);
            // EnemyMotor.Start() might not have run while it was disabled.
            // Give it a frame to initialize, then restore hostile state and target.
            StartCoroutine(CompleteHostilityAfterMotorStart());
        }

        IEnumerator CompleteHostilityAfterMotorStart()
        {
            yield return null;
            if (enemyMotor && GameManager.Instance && GameManager.Instance.PlayerEntityBehaviour)
                enemyMotor.MakeEnemyHostileToAttacker(GameManager.Instance.PlayerEntityBehaviour);
            // Keep the knight GameObject and its existing logical identity alive;
            // only remove the visitor coroutine controller.
            Destroy(this);
        }

        IEnumerator Lifetime(List<DFPosition> approachRoute)
        {
            yield return FollowRoute(approachRoute, 35f);
            if (!this) yield break;
            if (!completedLastRoute) { Finish(); yield break; }

            if (npc && npc.Asset) npc.Asset.IsIdle = true;
            yield return new WaitForSeconds(UnityEngine.Random.Range(0.8f, 1.8f));
            if (!this) yield break;
            root.LeaveOffering(encounter, this, transform.position, leaveRose, ordinal);
            yield return new WaitForSeconds(0.9f);

            List<DFPosition> departureRoute;
            if (TryMakeDepartureRoute(out departureRoute))
            {
                if (npc && npc.Asset) npc.Asset.IsIdle = false;
                yield return FollowRoute(departureRoute, 37f);
            }
            Finish();
        }

        bool TryMakeDepartureRoute(out List<DFPosition> departure)
        {
            departure = null;
            CityNavigation nav = encounter.Navigation;
            if (!nav) return false;
            DFPosition start;
            if (!TownGridPath.TryFindNearestWalkable(nav, transform.position, 2, out start))
                return false;
            for (int i = 0; i < 26; ++i)
            {
                float angle = UnityEngine.Random.Range(0f, Mathf.PI * 2f);
                float distance = UnityEngine.Random.Range(19f, 24f);
                Vector3 target = transform.position + new Vector3(Mathf.Cos(angle) * distance, 0, Mathf.Sin(angle) * distance);
                DFPosition goal;
                if (!TownGridPath.TryFindNearestWalkable(nav, target, 1, out goal))
                    continue;
                List<DFPosition> candidate;
                if (!TownGridPath.TryRoute(nav, start, goal, out candidate) || candidate.Count < 3)
                    continue;
                // Only accept an exit >= ~18m away in actual world space.
                if (MournersMod.HorizontalDistance(TownGridPath.CellPosition(nav, candidate[candidate.Count-1]), transform.position) < 17.5f)
                    continue;
                departure = candidate;
                return true;
            }
            return false;
        }

        IEnumerator FollowRoute(List<DFPosition> route, float timeout)
        {
            completedLastRoute = false;
            float began = Time.time;
            for (int n = 0; n < route.Count; ++n)
            {
                float blockedFor = 0;
                while (encounter.Navigation && MournersMod.HorizontalDistance(transform.position, TownGridPath.CellPosition(encounter.Navigation, route[n])) > 0.24f)
                {
                    if (!this || !encounter.Navigation || GameManager.Instance.PlayerEnterExit.IsPlayerInside ||
                        Time.time - began > timeout)
                        yield break;
                    if (GameManager.IsGamePaused) { yield return null; continue; }

                    Vector3 goal = TownGridPath.CellPosition(encounter.Navigation, route[n]);
                    Vector3 delta = goal - transform.position;
                    delta.y = 0;
                    if (delta.sqrMagnitude < 0.01f) break;
                    float step = Mathf.Min(Speed * Time.deltaTime, delta.magnitude);
                    Vector3 movement = delta.normalized * step;
                    Vector3 source = transform.position + Vector3.up * 0.65f;
                    // Actual wall check in addition to the town nav-grid, for modded buildings.
                    if (IsBlockingWall(source, movement, step))
                    {
                        blockedFor += Time.deltaTime;
                        if (blockedFor > 2.0f) yield break; // Never push through a house.
                        yield return null;
                        continue;
                    }
                    blockedFor = 0;
                    transform.position += movement;
                    transform.rotation = Quaternion.RotateTowards(transform.rotation,
                        Quaternion.LookRotation(delta.normalized, Vector3.up), 420f * Time.deltaTime);
                    yield return null;
                }
                if (!encounter.Navigation) yield break;
                // Keep Y aligned to DFU's map-based sidewalk elevation.
                Vector3 fixedPos = transform.position;
                fixedPos.y = TownGridPath.CellPosition(encounter.Navigation, route[n]).y;
                transform.position = fixedPos;
            }
            if (!encounter.Navigation) yield break;
            completedLastRoute = true;
        }

        public void Speak()
        {
            if (releasedFromMourning || GameManager.IsGamePaused) return;
            var identity = GetComponent<VisitorLogicalIdentity>();
            string title = identity && identity.Kind == "allied_mage" ? "Mage" : knight ? "Knight" : "Citizen";
            DaggerfallUI.Instance.PopupMessage(title + ": " + dialogue);
            Debug.Log("[MournersSP] Dialogue " + title + ": " + dialogue);
        }

        void OnDestroy()
        {
            if (root != null && encounter != null)
                root.ActorFinished(encounter, this);
        }

        static bool IsBlockingWall(Vector3 origin, Vector3 motion, float distance)
        {
            if (distance < 0.0001f) return false;
            RaycastHit[] hits = Physics.SphereCastAll(origin, 0.23f, motion.normalized, distance + 0.04f,
                ~0, QueryTriggerInteraction.Ignore);
            for (int i = 0; i < hits.Length; ++i)
            {
                Collider c = hits[i].collider;
                if (!c || c is TerrainCollider || c.GetComponentInParent<MobilePersonNPC>() ||
                    c.GetComponentInParent<DaggerfallEntityBehaviour>() ||
                    c.GetComponentInParent<DaggerfallLoot>())
                    continue;
                // Horizontal floor is okay; building wall, solid fence, etc. is not.
                if (hits[i].normal.y < 0.65f) return true;
            }
            return false;
        }

        void Finish()
        {
            if (root != null) root.ActorFinished(encounter, this);
            Destroy(gameObject);
        }
    }

    // Civilians use a child clickbox; knights have this callback on their
    // ORIGINAL damage collider objects, preserving normal combat and aggro.
    public sealed class VisitorDialogueProxy : MonoBehaviour, IPlayerActivable
    {
        internal VisitorActor Actor;
        public void Activate(RaycastHit hit)
        {
            if (Actor != null && hit.distance <= 4f) Actor.Speak();
        }
    }

    // Uses DFU's existing Red Rose inventory icon and item template, but is a
    // separate ITEM CLASS with its own UseItem() behavior and save identity.
    // This item is held in either the player's inventory OR the independent
    // world object, never inside a loot container.
    // No custom item template or unknown texture archive numbers required.
    public class MemorialRoseItem : DaggerfallUnityItem
    {
        public virtual int FlowerKind { get { return 0; } }
        public MemorialRoseItem() : this(ItemGroups.PlantIngredients1, (int)PlantIngredients1.Red_rose) { }
        protected MemorialRoseItem(ItemGroups group, int template) : base(group,
            DaggerfallUnity.Instance.ItemHelper.GetGroupIndex(group, template))
        {
            shortName = ItemName;
            value = 1;
            weightInKg = 0.1f;
        }
        public override string ItemName
        {
            get { return FlowerKind == 1 ? "Memorial Black Rose" :
                FlowerKind == 2 ? "Memorial Yellow Flower" : "Memorial Red Rose"; }
        }
        public override string LongName { get { return ItemName + " (use to place on the ground)"; } }
        // Never merge this mod item with an ordinary red rose ingredient. A merged
        // stack would lose the custom UseItem() behaviour and save class.
        public override bool IsStackable() { return false; }

        public override ItemData_v1 GetSaveData()
        {
            ItemData_v1 data = base.GetSaveData();
            data.className = GetType().ToString();
            return data;
        }

        public override bool UseItem(ItemCollection collection)
        {
            if (GameManager.Instance == null || GameManager.Instance.PlayerEnterExit == null ||
                GameManager.Instance.PlayerEnterExit.IsPlayerInside)
            {
                DaggerfallUI.Instance.PopupMessage("The Memorial Rose can only be placed outdoors.");
                return true;
            }
            if (collection != null && collection != GameManager.Instance.PlayerEntity.Items)
            {
                DaggerfallUI.Instance.PopupMessage("Take the rose into your inventory before placing it.");
                return true;
            }
            if (collection == null) collection = GameManager.Instance.PlayerEntity.Items;
            // From inventory USE, put it roughly 1.8m ahead of player's feet.
            Vector3 direction = GameManager.Instance.PlayerObject.transform.forward;
            direction.y = 0;
            direction.Normalize();
            Vector3 feet = GameManager.Instance.PlayerMotor.FindGroundPosition();
            Vector3 candidate = feet + direction * 1.8f;
            Vector3 ground;
            if (!MournersMod.TryFindFlowerGround(candidate, out ground))
            {
                DaggerfallUI.Instance.PopupMessage("Cannot find walkable ground for the Memorial Rose.");
                return true;
            }
            string newKey = "placed-rose/" + Guid.NewGuid().ToString("N");
            if (MournersMod.PlaceMemorialRose(ground, "player-placed", newKey, 0UL, this))
            {
                collection.RemoveItem(this);
                DaggerfallUI.Instance.PopupMessage("You place the " + ItemName + " on the ground.");
            }
            return true;
        }
    }

    public sealed class MemorialBlackRoseItem : MemorialRoseItem
    {
        public override int FlowerKind { get { return 1; } }
        public MemorialBlackRoseItem() : base(ItemGroups.PlantIngredients2, (int)PlantIngredients2.Black_rose) { }
    }
    public sealed class MemorialYellowFlowerItem : MemorialRoseItem
    {
        public override int FlowerKind { get { return 2; } }
        public MemorialYellowFlowerItem() : base(ItemGroups.PlantIngredients1, (int)PlantIngredients1.Yellow_flowers) { }
    }

    // World-only expiry. Inventory items have no timer.
    public sealed class MemorialFlowerLifetime : MonoBehaviour
    {
        public const float WorldLifetimeSeconds = 30f * 60f;
        public bool KeepUnderModRoot { get { return fixedRoot; } }
        float expires;
        bool fixedRoot;
        double worldX, worldZ;
        float height;
        public void Begin(bool modRoot)
        {
            expires = Time.realtimeSinceStartup + WorldLifetimeSeconds;
            fixedRoot = modRoot;
            var gm = GameManager.Instance;
            Vector3 delta = transform.position - gm.PlayerObject.transform.position;
            worldX = gm.PlayerGPS.WorldX + delta.x * 40.0;
            worldZ = gm.PlayerGPS.WorldZ + delta.z * 40.0;
            height = transform.position.y - gm.StreamingWorld.WorldCompensation.y;
        }
        void LateUpdate()
        {
            if (Time.realtimeSinceStartup >= expires) { Destroy(gameObject); return; }
            // Temporary world flowers are never carried across save loads.
            if (SaveLoadManager.Instance != null && SaveLoadManager.Instance.LoadInProgress)
            { Destroy(gameObject); return; }
            if (!fixedRoot || GameManager.Instance == null) return;
            var gm = GameManager.Instance;
            bool outside = gm.PlayerEnterExit != null && !gm.PlayerEnterExit.IsPlayerInside;
            foreach (var renderer in GetComponentsInChildren<Renderer>()) renderer.enabled = outside;
            foreach (var collider in GetComponents<Collider>()) collider.enabled = outside;
            if (!outside) return;
            // The mod root stays at zero; this child follows DF world coordinates
            // rather than drifting when StreamingTarget shifts its origin.
            Vector3 player = gm.PlayerObject.transform.position;
            transform.position = new Vector3(player.x + (float)((worldX - gm.PlayerGPS.WorldX) / 40.0),
                height + gm.StreamingWorld.WorldCompensation.y,
                player.z + (float)((worldZ - gm.PlayerGPS.WorldZ) / 40.0));
        }
    }

    // One independent Unity GameObject, distinct from DFU loot and enemy objects.
    // IPlayerActivable is checked by PlayerActivate on the actual collider hit.
    // When clicked, this object directly transfers its item to the player and
    // destroys itself; using the inventory item creates another world GameObject.
    public sealed class MemorialRoseWorldObject : MonoBehaviour, IPlayerActivable
    {
        MemorialRoseItem item;
        bool pickedUp;

        internal ulong ItemUID { get { return item != null ? item.UID : 0UL; } }
        internal void SetItem(MemorialRoseItem inventoryItem) { item = inventoryItem; }

        public void Activate(RaycastHit hit)
        {
            if (pickedUp || item == null || hit.distance > 3.5f || GameManager.IsGamePaused)
                return;
            if (GameManager.Instance == null || GameManager.Instance.PlayerEntity == null) return;
            pickedUp = true;
            try
            {
                // The same item UID moves world -> inventory. There is NO
                // DaggerfallLoot container or inventory loot window involved.
                GameManager.Instance.PlayerEntity.Items.AddItem(item, noStack: true);
                VisitorLogicalIdentity id = GetComponent<VisitorLogicalIdentity>();
                Debug.Log("[MournersSP] PICKUP worldObject=" + (id ? id.ObjectKey : "unknown") +
                    " itemUID=" + item.UID);
                DaggerfallUI.Instance.PopupMessage("You pick up the " + item.ItemName + ".");
                Destroy(gameObject);
            }
            catch (Exception ex)
            {
                pickedUp = false;
                Debug.LogError("[MournersSP] Rose pickup failed: " + ex);
            }
        }
    }

    // Uses the installed game's red-rose inventory sprite, with direct world pickup.
    // The root remains an independent GameObject, not a loot container.
    public sealed class FlowerModel : MonoBehaviour
    {
        Sprite ownedSprite;

        public static void Attach(GameObject worldObject, DaggerfallUnityItem item)
        {
            if (!worldObject || worldObject.GetComponentInChildren<FlowerModel>()) return;
            var image = DaggerfallUnity.Instance.ItemHelper.GetItemImage(item, true);
            Texture2D texture = image.texture;
            if (!texture) throw new Exception("Cannot load the rose item sprite.");
            GameObject visual = new GameObject("MemorialRoseVisual");
            visual.transform.SetParent(worldObject.transform, false);
            visual.transform.localPosition = new Vector3(0f, 0.18f, 0f);
            FlowerModel flower = visual.AddComponent<FlowerModel>();
            // Approx. 36cm tall. Use DFU's cached texture without owning/destroying it.
            flower.ownedSprite = Sprite.Create(texture,
                new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(0.5f, 0.5f), texture.height / 0.36f);
            SpriteRenderer renderer = visual.AddComponent<SpriteRenderer>();
            renderer.sprite = flower.ownedSprite;
        }

        void LateUpdate()
        {
            Camera camera = Camera.main;
            if (camera)
                transform.rotation = Quaternion.Euler(0f, camera.transform.eulerAngles.y, 0f);
        }

        void OnDestroy()
        {
            if (ownedSprite) Destroy(ownedSprite);
        }
    }

    // Small, bounded A* using DFU's town navigation, which excludes house footprints.
    // Each path point is in Unity scene coordinates and raised to civilian sprite-centre.
    internal static class TownGridPath
    {
        const int MaxVisited = 2200;
        const int MaxPathSteps = 160;
        static readonly int[] DX = { 0, 0, 1, -1 };
        static readonly int[] DY = { -1, 1, 0, 0 };

        static int Key(DFPosition p, int width) { return p.Y * width + p.X; }
        static DFPosition Decode(int key, int width) { return new DFPosition(key % width, key / width); }
        static int Dist(DFPosition a, DFPosition b) { return Mathf.Abs(a.X - b.X) + Mathf.Abs(a.Y - b.Y); }

        static bool Walkable(CityNavigation nav, DFPosition cell)
        {
            if (cell.X < 0 || cell.Y < 0 || cell.X >= nav.NavGridWidth || cell.Y >= nav.NavGridHeight)
                return false;
            return nav.GetNavGridWeightLocal(cell) > 0;
        }

        public static Vector3 CellPosition(CityNavigation nav, DFPosition cell)
        {
            Vector3 point = nav.WorldToScenePosition(nav.NavGridToWorldPosition(cell));
            point.y += 1f;
            return point;
        }

        public static bool TryFindNearestWalkable(CityNavigation nav, Vector3 scene, int radius, out DFPosition cell)
        {
            cell = new DFPosition(-1, -1);
            try
            {
                DFPosition baseCell = nav.WorldToNavGridPosition(nav.SceneToWorldPosition(scene));
                int best = int.MaxValue;
                for (int y = -radius; y <= radius; ++y)
                    for (int x = -radius; x <= radius; ++x)
                    {
                        DFPosition test = new DFPosition(baseCell.X + x, baseCell.Y + y);
                        if (!Walkable(nav, test)) continue;
                        int metric = x*x + y*y;
                        if (metric < best) { best = metric; cell = test; }
                    }
                return best != int.MaxValue;
            }
            catch (Exception) { return false; }
        }

        public static bool TryRoute(CityNavigation nav, DFPosition begin, DFPosition end, out List<DFPosition> route)
        {
            route = null;
            if (!Walkable(nav, begin) || !Walkable(nav, end)) return false;
            int width = nav.NavGridWidth;
            int goalKey = Key(end, width);
            int firstKey = Key(begin, width);
            List<int> open = new List<int>();
            HashSet<int> closed = new HashSet<int>();
            Dictionary<int,int> from = new Dictionary<int,int>();
            Dictionary<int,int> g = new Dictionary<int,int>();
            open.Add(firstKey);
            g[firstKey] = 0;
            for (int visited = 0; open.Count > 0 && visited < MaxVisited; ++visited)
            {
                int bestIndex = 0, bestScore = int.MaxValue;
                for (int i = 0; i < open.Count; ++i)
                {
                    int key = open[i];
                    int score = g[key] + Dist(Decode(key, width), end);
                    if (score < bestScore) { bestScore = score; bestIndex = i; }
                }
                int current = open[bestIndex];
                open.RemoveAt(bestIndex);
                if (current == goalKey)
                {
                    List<DFPosition> reverse = new List<DFPosition>();
                    int k = goalKey;
                    while (k != firstKey && reverse.Count < MaxPathSteps)
                    {
                        reverse.Add(Decode(k, width));
                        k = from[k];
                    }
                    if (k != firstKey || reverse.Count == 0) return false;
                    reverse.Reverse();
                    route = reverse;
                    return true;
                }
                closed.Add(current);
                DFPosition p = Decode(current, width);
                for (int d = 0; d < 4; ++d)
                {
                    DFPosition n = new DFPosition(p.X + DX[d], p.Y + DY[d]);
                    if (!Walkable(nav, n)) continue;
                    int nk = Key(n, width);
                    if (closed.Contains(nk)) continue;
                    int tentative = g[current] + 1;
                    int oldG;
                    if (!g.TryGetValue(nk, out oldG) || tentative < oldG)
                    {
                        from[nk] = current;
                        g[nk] = tentative;
                        if (!open.Contains(nk)) open.Add(nk);
                    }
                }
            }
            return false;
        }
    }
}
